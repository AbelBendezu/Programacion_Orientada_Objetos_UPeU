
public class Carrera 
{
    private int CodCarrera;
    private String nomCarrera;
    /**
     * @return the CodCarrera
     */
    public int getCodCarrera() 
    {
        return CodCarrera;
    }

    /**
     * @param CodCarrera the CodCarrera to set
     */
    public void setCodCarrera(int CodCarrera) 
    {
        this.CodCarrera = CodCarrera;
    }

    /**
     * @return the nomCarrera
     */
    public String getNomCarrera() 
    {
        return nomCarrera;
    }

    /**
     * @param nomCarrera the nomCarrera to set
     */
    public void setNomCarrera(String nomCarrera) 
    {
        this.nomCarrera = nomCarrera;
    }
    public Carrera()
    {
        this.setCodCarrera(0);
        this.setNomCarrera("");
    }
    public Carrera(int codC, String nomC)
    {
        this.setCodCarrera(codC);
        this.setNomCarrera(nomC);
    }
    public void LeerDatos()
    {
       System.out.println("Ingrese Codigo");
       System.out.println("Ingrese NomCarrera");
    }
    public void ImprimirDatos()
    {
       System.out.println("Codigo" + this.getCodCarrera()); 
       System.out.println("Nombre de Carrera" + this.getNomCarrera()); 
    }
}

