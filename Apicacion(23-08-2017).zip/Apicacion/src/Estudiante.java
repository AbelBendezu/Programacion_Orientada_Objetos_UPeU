
import java.util.Scanner;

    public class Estudiante 
{
    private int Codigo;
    private String Nombre;
    private String apPaterno;
    private String apMaterno;
    private int Edad;
    private Carrera nomCarrera;
    //Metodo de Encapsulamiento (Set % Get)
    public int getCodigo() 
    {
        return Codigo;
    }

    public void setCodigo(int Codigo) 
    {
        this.Codigo = Codigo;
    }

    public String getNombre() 
    {
        return Nombre;
    }

    public void setNombre(String Nombre)
    {
        this.Nombre = Nombre;
    }

    public String getApPaterno() 
    {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno)
    {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() 
    {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) 
    {
        this.apMaterno = apMaterno;
    }

    public int getEdad() 
    {
        return Edad;
    }

    public void setEdad(int Edad) 
    {
        this.Edad = Edad;
    }

    /**
     * @return the nomCarrera
     */
    public Carrera getNomCarrera() 
    {
        return nomCarrera;
    }

    /**
     * @param nomCarrera the nomCarrera to set
     */
    public void setNomCarrera(Carrera nomCarrera) 
    {
        this.nomCarrera = nomCarrera;
    }
        //Inicio de Desarrollo
    //*Constructores
    public Estudiante()
    {
    
    }
    public Estudiante (int cod,String nom, String apPat, String apMat, int e, Carrera Carr)
    {
        this.setCodigo(cod);
        this.setNombre(nom);
        this.setApPaterno(apPat);
        this.setApMaterno(apMat);
        this.setEdad(e);
        this.setNomCarrera(Carr);
    }
    public void LeerDatos()
    {
       Scanner lector = new Scanner(System.in);
       System.out.println("Ingrese Codigo");
       this.setCodigo(lector.nextInt());
       System.out.println("Ingrese Nombre");
       this.setNombre(lector.next());
       System.out.println("Ingrese Apellido Paterno");
       this.setApPaterno(lector.next());
       System.out.println("Ingrese Apellido Materno");
       this.setApMaterno(lector.next());
       System.out.println("Ingrese Edad");
       this.setEdad(lector.nextInt());
       Carrera oC = new Carrera(1, "Ing.Sistemas");
       this.setNomCarrera(oC);
    }
    public void ImprimirDatos()
    {
       System.out.println("Codigo" + this.getCodigo());
       System.out.println("Nombre" + this.getNombre());
       System.out.println("Apellido Paterno" + this.getApPaterno());
       System.out.println("Apellido Materno" + this.getApMaterno());
       System.out.println("Edad" + this.getEdad());
       System.out.println("Edad" + this.getNomCarrera().getNomCarrera());
    }
}
