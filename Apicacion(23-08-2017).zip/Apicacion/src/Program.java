
public class Program 
{
    public static void main(String[] args) 
    {
        Carrera oC = new Carrera(1, "Ing.Sistemas");
        Estudiante oE = new Estudiante();
        oE.LeerDatos();
        
    }
}
