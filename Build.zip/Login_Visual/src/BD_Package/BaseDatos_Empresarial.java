package BD_Package;

import java.util.ArrayList;

import Datos_Trabajador.DatosUsuarioEmpresarial;

public class BaseDatos_Empresarial 
{
	public static ArrayList<DatosUsuarioEmpresarial> ListarRUC 			= new ArrayList<DatosUsuarioEmpresarial>();
	public static ArrayList<DatosUsuarioEmpresarial> ListarNombre 		= new ArrayList<DatosUsuarioEmpresarial>();
	public static ArrayList<DatosUsuarioEmpresarial> ListarApPaterno  	= new ArrayList<DatosUsuarioEmpresarial>();
	public static ArrayList<DatosUsuarioEmpresarial> ListarApMaterno  	= new ArrayList<DatosUsuarioEmpresarial>();
	public static ArrayList<DatosUsuarioEmpresarial> ListarRazSocial  	= new ArrayList<DatosUsuarioEmpresarial>();
	public static ArrayList<DatosUsuarioEmpresarial> ListarGenero 		= new ArrayList<DatosUsuarioEmpresarial>();
	public static ArrayList<DatosUsuarioEmpresarial> ListarNumCelular   = new ArrayList<DatosUsuarioEmpresarial>();
	
	public static void AgregarLista(DatosUsuarioEmpresarial p)
	{
		ListarRUC		.add(p);
		ListarNombre	.add(p);
		ListarApPaterno	.add(p);
		ListarApMaterno	.add(p);
		ListarRazSocial	.add(p);
		ListarGenero	.add(p);
		ListarNumCelular.add(p);
	}
	public static void ListarRUC()
	{
		for (int i = 0; i < ListarRUC.size()-1; i++) 
		{
			DatosUsuarioEmpresarial oP = (DatosUsuarioEmpresarial)ListarRUC.get(i);
		}
	}
	public static void ListarNombre()
	{
		for (int i = 0; i < ListarNombre.size()-1; i++) 
		{
			DatosUsuarioEmpresarial oP = (DatosUsuarioEmpresarial)ListarNombre.get(i);
		}
	}
	public static void ListarApPater()
	{
		for (int i = 0; i < ListarNombre.size()-1; i++) 
		{
			DatosUsuarioEmpresarial oP = (DatosUsuarioEmpresarial)ListarNombre.get(i);
		}
	}
	public static void ListarApMater()
	{
		for (int i = 0; i < ListarNombre.size()-1; i++) 
		{
			DatosUsuarioEmpresarial oP = (DatosUsuarioEmpresarial)ListarNombre.get(i);
		}
	}
}
