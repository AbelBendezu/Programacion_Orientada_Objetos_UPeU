package BD_Package;

import java.util.ArrayList;
import java.util.List;

import Datos_Trabajador.DatosUsuarioNatural;

public class BaseDatos_Natural 
{
	public static List<DatosUsuarioNatural> ListaDNI 			= new ArrayList<DatosUsuarioNatural>();
	public static List<DatosUsuarioNatural> ListaNombres 		= new ArrayList<DatosUsuarioNatural>();
	public static List<DatosUsuarioNatural> ListaApPater 		= new ArrayList<DatosUsuarioNatural>();
	public static List<DatosUsuarioNatural> ListaApMater 		= new ArrayList<DatosUsuarioNatural>();
	public static List<DatosUsuarioNatural> ListaDireccion 		= new ArrayList<DatosUsuarioNatural>();
	public static List<DatosUsuarioNatural> ListaGenero 		= new ArrayList<DatosUsuarioNatural>();
	public static List<DatosUsuarioNatural> ListaNumCelular 	= new ArrayList<DatosUsuarioNatural>();
	
	public static void AgregarLista(DatosUsuarioNatural p)
	{
		ListaDNI.		add(p);
		ListaNombres.	add(p);
		ListaApPater.	add(p);
		ListaApMater.	add(p);
		ListaDireccion.	add(p);
		ListaGenero.	add(p);
		ListaNumCelular.add(p);
	}
	public static void ListarDNI()
	{
		for (int i = 0; i < ListaDNI.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaDNI.get(i);
		}
	}
	public static void ListarNombres()
	{
		for (int i = 0; i < ListaNombres.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaNombres.get(i);
		}
	}
	public static void ListarApPater()
	{
		for (int i = 0; i < ListaApPater.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaApPater.get(i);
		}
	}
	public static void ListarApMater()
	{
		for (int i = 0; i < ListaApMater.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaApMater.get(i);
		}
	}
	public static void ListarDireccion()
	{
		for (int i = 0; i < ListaDireccion.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaDireccion.get(i);
		}
	}
	public static void ListaGenero()
	{
		for (int i = 0; i < ListaGenero.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaGenero.get(i);
		}
	}
	public static void ListarNumCelular()
	{
		for (int i = 0; i < ListaNumCelular.size()-1; i++) 
		{
			DatosUsuarioNatural oP = (DatosUsuarioNatural)ListaNumCelular.get(i);
		}
	}
}
