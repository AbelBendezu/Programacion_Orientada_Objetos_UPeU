package Datos_Administrador;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuPrincipal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPrincipal frame = new MenuPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnArchivo = new JMenu("Archivo");
		menuBar.add(mnArchivo);
		
		JMenu mnEditarUsuario = new JMenu("Editar Usuario");
		mnArchivo.add(mnEditarUsuario);
		
		JMenuItem mntmUsuarioNatural = new JMenuItem("Usuario Natural");
		mnEditarUsuario.add(mntmUsuarioNatural);
		
		JMenuItem mntmUsuarioEmpresarial = new JMenuItem("Usuario Empresarial");
		mnEditarUsuario.add(mntmUsuarioEmpresarial);
		
		JMenu mnAdministrarUsuarios = new JMenu("Administrar Usuarios");
		mnArchivo.add(mnAdministrarUsuarios);
		
		JMenuItem mntmUsuarioNatural_1 = new JMenuItem("Usuario Natural");
		mnAdministrarUsuarios.add(mntmUsuarioNatural_1);
		
		JMenuItem mntmUsuarioEmpresarial_1 = new JMenuItem("Usuario Empresarial");
		mnAdministrarUsuarios.add(mntmUsuarioEmpresarial_1);
		
		JMenuItem mntmSalir = new JMenuItem("Salir");
		mntmSalir.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		mnArchivo.add(mntmSalir);
		
		JMenu mnAcciones = new JMenu("Acciones");
		menuBar.add(mnAcciones);
		
		JMenu mnListarDepositos = new JMenu("Listar Depositos");
		mnAcciones.add(mnListarDepositos);
		
		JMenuItem mntmUsuarioNatural_2 = new JMenuItem("Usuario Natural");
		mnListarDepositos.add(mntmUsuarioNatural_2);
		
		JMenuItem mntmUsuarioEmpresarial_2 = new JMenuItem("Usuario Empresarial");
		mnListarDepositos.add(mntmUsuarioEmpresarial_2);
		
		JMenu mnListarRetiros = new JMenu("Listar Retiros");
		mnAcciones.add(mnListarRetiros);
		
		JMenuItem mntmCuentaNatural = new JMenuItem("Cuenta Natural");
		mnListarRetiros.add(mntmCuentaNatural);
		
		JMenuItem mntmCuentaEmpresarial = new JMenuItem("Cuenta Empresarial");
		mnListarRetiros.add(mntmCuentaEmpresarial);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}

}
