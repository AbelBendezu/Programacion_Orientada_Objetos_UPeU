package Datos_Trabajador;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class BuscarUsuario_Empresarial extends JFrame
{
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JLabel lblDocumentoDeIdentidad;
	private JTextField textField_5;
	private JTable table;

	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					BuscarUsuario_Empresarial frame = new BuscarUsuario_Empresarial();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarUsuario_Empresarial() 
	{
		setBounds(100, 100, 410, 315);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuarioNatural = new JLabel("Buscar Usuario Natural");
		lblUsuarioNatural.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsuarioNatural.setFont(new Font("Tw Cen MT", Font.PLAIN, 20));
		lblUsuarioNatural.setBounds(107, 11, 194, 28);
		contentPane.add(lblUsuarioNatural);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombre.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblNombre.setBounds(10, 49, 65, 19);
		contentPane.add(lblNombre);
		
		textField = new JTextField();
		textField.setBounds(284, 50, 100, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblApPaterno = new JLabel("Ap. Paterno:");
		lblApPaterno.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblApPaterno.setBounds(196, 50, 89, 19);
		contentPane.add(lblApPaterno);
		
		textField_1 = new JTextField();
		textField_1.setBounds(75, 50, 100, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		lblDocumentoDeIdentidad = new JLabel("DNI:");
		lblDocumentoDeIdentidad.setHorizontalAlignment(SwingConstants.CENTER);
		lblDocumentoDeIdentidad.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblDocumentoDeIdentidad.setBounds(132, 80, 31, 19);
		contentPane.add(lblDocumentoDeIdentidad);
		
		textField_5 = new JTextField();
		textField_5.setBounds(173, 81, 100, 19);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		btnNewButton.setBounds(25, 222, 100, 43);
		contentPane.add(btnNewButton);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
			}
		});
		btnSalir.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		btnSalir.setBounds(265, 222, 100, 43);
		contentPane.add(btnSalir);
		
		table = new JTable();
		table.setModel(new DefaultTableModel
				(
			new Object[][] 
					{
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
					},
			new String[] 
					{
							"null"
					}
		));
		table.setBounds(10, 115, 374, 96);
		contentPane.add(table);
	}
}
