package Datos_Trabajador;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CrearUsuario_Natural extends JFrame
{
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JLabel lblGenero;
	private JLabel lblNumeroDeCelular;
	private JTextField textField_4;
	private JLabel lblDocumentoDeIdentidad;
	private JTextField textField_5;

	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					CrearUsuario_Natural frame = new CrearUsuario_Natural();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CrearUsuario_Natural() 
	{
		setBounds(100, 100, 410, 315);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuarioNatural = new JLabel("Usuario Natural");
		lblUsuarioNatural.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsuarioNatural.setFont(new Font("Tw Cen MT", Font.PLAIN, 20));
		lblUsuarioNatural.setBounds(130, 11, 143, 28);
		contentPane.add(lblUsuarioNatural);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombre.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblNombre.setBounds(110, 50, 65, 19);
		contentPane.add(lblNombre);
		
		textField = new JTextField();
		textField.setBounds(204, 74, 100, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblApPaterno = new JLabel("Ap. Paterno:");
		lblApPaterno.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblApPaterno.setBounds(86, 75, 89, 19);
		contentPane.add(lblApPaterno);
		
		textField_1 = new JTextField();
		textField_1.setBounds(204, 50, 100, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblApMaterno = new JLabel("Ap. Materno:");
		lblApMaterno.setHorizontalAlignment(SwingConstants.CENTER);
		lblApMaterno.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblApMaterno.setBounds(84, 98, 91, 19);
		contentPane.add(lblApMaterno);
		
		textField_2 = new JTextField();
		textField_2.setBounds(204, 99, 100, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblDireccion = new JLabel("Direccion:");
		lblDireccion.setHorizontalAlignment(SwingConstants.CENTER);
		lblDireccion.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblDireccion.setBounds(107, 121, 68, 19);
		contentPane.add(lblDireccion);
		
		textField_3 = new JTextField();
		textField_3.setBounds(204, 122, 100, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		lblGenero = new JLabel("Genero:");
		lblGenero.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblGenero.setHorizontalAlignment(SwingConstants.CENTER);
		lblGenero.setBounds(110, 143, 65, 19);
		contentPane.add(lblGenero);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Masculino", "Femenino"}));
		comboBox.setBounds(204, 145, 100, 19);
		contentPane.add(comboBox);
		
		lblNumeroDeCelular = new JLabel("Numero de Celular:");
		lblNumeroDeCelular.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblNumeroDeCelular.setBounds(39, 166, 136, 19);
		contentPane.add(lblNumeroDeCelular);
		
		textField_4 = new JTextField();
		textField_4.setBounds(204, 167, 100, 19);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		lblDocumentoDeIdentidad = new JLabel("DNI:");
		lblDocumentoDeIdentidad.setHorizontalAlignment(SwingConstants.CENTER);
		lblDocumentoDeIdentidad.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		lblDocumentoDeIdentidad.setBounds(144, 192, 31, 19);
		contentPane.add(lblDocumentoDeIdentidad);
		
		textField_5 = new JTextField();
		textField_5.setBounds(204, 188, 100, 19);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Registrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				
			}
		});
		btnNewButton.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		btnNewButton.setBounds(25, 222, 100, 43);
		contentPane.add(btnNewButton);
		
		JButton btnNuevo = new JButton("Nuevo");
		btnNuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				
			}
		});
		btnNuevo.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		btnNuevo.setBounds(144, 222, 100, 43);
		contentPane.add(btnNuevo);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
			}
		});
		btnSalir.setFont(new Font("Tw Cen MT", Font.PLAIN, 17));
		btnSalir.setBounds(265, 222, 100, 43);
		contentPane.add(btnSalir);
	}
}
