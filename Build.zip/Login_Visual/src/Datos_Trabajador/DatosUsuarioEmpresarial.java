package Datos_Trabajador;

import java.util.Scanner;

public class DatosUsuarioEmpresarial 
{
	private static class DatosGenerales
	{
		//Se introduce Primeros Datos
		private String RUC;
		private String Nombre;
		private String ApellidoPaterno;
		private String ApellidoMaterno;
		private String RazonSocial;
		private boolean Genero;
		private String NumeroCelular;
		//Metodos Set&Get
		public void setRUC(String rUC) 
		{
			RUC = rUC;
		}
		public String getRUC() 
		{
			return RUC;
		}
		public void setNombre(String nombre) 
		{
			Nombre = nombre;
		}
		public String getNombre() 
		{
			return Nombre;
		}
		public void setApellidoPaterno(String apellidoPaterno) 
		{
			ApellidoPaterno = apellidoPaterno;
		}
		public String getApellidoPaterno() 
		{
			return ApellidoPaterno;
		}
		public void setApellidoMaterno(String apellidoMaterno)
		{
			ApellidoMaterno = apellidoMaterno;
		}
		public String getApellidoMaterno() 
		{
			return ApellidoMaterno;
		}
		public void setRazonSocial(String razonSocial) 
		{
			RazonSocial = razonSocial;
		}
		public String getRazonSocial() 
		{
			return RazonSocial;
		}
		public void setGenero(boolean genero) 
		{
			Genero = genero;
		}
		public boolean isGenero() 
		{
			return Genero;
		}
		public void setNumeroCelular(String numeroCelular) 
		{
			NumeroCelular = numeroCelular;
		}
		public String getNumeroCelular() 
		{
			return NumeroCelular;
		}
		public DatosGenerales() 
		{
			this.setRUC("");
			this.setNombre("");
			this.setApellidoPaterno("");
			this.setApellidoMaterno("");
			this.setRazonSocial("");
			this.setGenero(Genero);
			this.setNumeroCelular("");
		}
		public DatosGenerales(String ruc,String nombre,String apPaterno,String apMaterno,String razSocial,boolean genero,String numCelular)
		{
			this.setRUC(ruc);
			this.setNombre(nombre);
			this.setApellidoPaterno(apPaterno);
			this.setApellidoMaterno(apMaterno);
			this.setRazonSocial(razSocial);
			this.setGenero(genero);
			this.setNumeroCelular(numCelular);
		}
		public void LeerDatos()
		{
			Scanner lector = new Scanner(System.in);
			System.out.println("Ingrese RUC:");
			this.setRUC(lector.next());
			System.out.println("Ingrese Nombre:");
			this.setNombre(lector.next());
			System.out.println("Ingrese Apellido Paterno:");
			this.setApellidoPaterno(lector.next());
			System.out.println("Ingrese Apellido Materno:");
			this.setApellidoMaterno(lector.next());
			System.out.println("Determine Razon Social:");
			this.setRazonSocial(lector.next());
			System.out.println("Determine Genero:");
			this.setGenero(lector.nextBoolean());
			System.out.println("Ingrese Numero de Celular:");
			this.setNumeroCelular(lector.next());
		}
	}
}
