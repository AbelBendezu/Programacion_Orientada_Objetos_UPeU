package Datos_Trabajador;

import java.util.Scanner;

public class DatosUsuarioNatural 
{
	private static class DatosGenerales
	{
		//Se Introducen los primeros Datos
		private int DNI;
		private String Nombre;
		private String ApellidoPaterno;
		private String ApellidoMaterno;
		private String Direccion;
		private boolean Genero;
		private String NumeroCelular;
		//Metodo Set&Get
		public void setDNI(int dNI) 
		{
			DNI = dNI;
		}
		public int getDNI() 
		{
			return DNI;
		}
		public void setNombre(String nombre) 
		{
			Nombre = nombre;
		}
		public String getNombre() 
		{
			return Nombre;
		}
		public void setApellidoPaterno(String apellidoPaterno) 
		{
			ApellidoPaterno = apellidoPaterno;
		}
		public String getApellidoPaterno() 
		{
			return ApellidoPaterno;
		}
		public void setApellidoMaterno(String apellidoMaterno) 
		{
			ApellidoMaterno = apellidoMaterno;
		}
		public String getApellidoMaterno() 
		{
			return ApellidoMaterno;
		}
		public void setDireccion(String direccion) 
		{
			Direccion = direccion;
		}
		public String getDireccion() 
		{
			return Direccion;
		}
		public void setGenero(boolean genero) 
		{
			Genero = genero;
		}
		public boolean isGenero() 
		{
			return Genero;
		}
		public void setNumeroCelular(String numeroCelular)
		{
			NumeroCelular = numeroCelular;
		}
		public String getNumeroCelular() 
		{
			return NumeroCelular;
		}
		public DatosGenerales() 
		{
			this.setDNI(1);
			this.setNombre("");
			this.setApellidoPaterno("");
			this.setApellidoMaterno("");
			this.setDireccion("");
			this.setGenero(Genero);
			this.setNumeroCelular("");
		}
		public DatosGenerales(int dni,String nombre,String apPaterno,String apMaterno,String direccion,boolean genero,String numCel)
		{
			this.setDNI(dni);
			this.setNombre(nombre);
			this.setApellidoPaterno(apPaterno);
			this.setApellidoMaterno(apMaterno);
			this.setDireccion(direccion);
			this.setGenero(genero);
			this.setNumeroCelular(numCel);
		}
		public void LeerDatos()
		{
			Scanner lector = new Scanner(System.in);
			System.out.println("Ingrese DNI:");
			this.setDNI(lector.nextInt());
			System.out.println("Ingrese Nombre:");
			this.setNombre(lector.next());;
			System.out.println("Ingrese Apellido Paterno:");
			this.setApellidoPaterno(lector.next());
			System.out.println("Ingrese Apellido Materno:");
			this.setApellidoMaterno(lector.next());
			System.out.println("Ingrese Direccion:");
			this.setDireccion(lector.next());
			System.out.println("Determine Genero:");
			this.setGenero(lector.nextBoolean());
			System.out.println("Ingrese Numero de Celular:");
			this.setNumeroCelular(lector.next());
		}
	}
}
