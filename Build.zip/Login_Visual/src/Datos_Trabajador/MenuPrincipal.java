package Datos_Trabajador;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Visual_Package.Login_Principal;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuPrincipal extends JFrame
{
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run() 
			{
				try 
				{
					MenuPrincipal frame = new MenuPrincipal();
					frame.setVisible(true);
				}
					catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public MenuPrincipal() 
	{
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnArchivo = new JMenu("Archivo");
		menuBar.add(mnArchivo);
		
		JMenu mnCrearUsuario = new JMenu("Crear Usuario");
		mnArchivo.add(mnCrearUsuario);
		
		JMenuItem mntmUsuarioNatural = new JMenuItem("Usuario Natural");
		mntmUsuarioNatural.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				CrearUsuario_Natural formFormulario1 = new CrearUsuario_Natural();
				formFormulario1.setVisible(true);
				MenuPrincipal.this.setVisible(false);
			}
		});
		mnCrearUsuario.add(mntmUsuarioNatural);
		
		JMenuItem mntmUsuarioEmpresarial = new JMenuItem("Usuario Empresarial");
		mntmUsuarioEmpresarial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				CrearUsuario_Empresarial formFormulario1 = new CrearUsuario_Empresarial();
				formFormulario1.setVisible(true);
				MenuPrincipal.this.setVisible(false);
			}
		});
		mnCrearUsuario.add(mntmUsuarioEmpresarial);
		
		JMenu mnBuscarUsuario = new JMenu("Buscar Usuario");
		mnArchivo.add(mnBuscarUsuario);
		
		JMenuItem mntmUsuarioNatural_1 = new JMenuItem("Usuario Natural");
		mntmUsuarioNatural_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				BuscarUsuario_Natural formFormulario1 = new BuscarUsuario_Natural();
				formFormulario1.setVisible(true);
				MenuPrincipal.this.setVisible(false);
			}
		});
		mnBuscarUsuario.add(mntmUsuarioNatural_1);
		
		JMenuItem mntmUsuarioEmpresarial_1 = new JMenuItem("Usuario Empresarial");
		mntmUsuarioEmpresarial_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				BuscarUsuario_Empresarial formFormulario1 = new BuscarUsuario_Empresarial();
				formFormulario1.setVisible(true);
				MenuPrincipal.this.setVisible(false);
			}
		});
		mnBuscarUsuario.add(mntmUsuarioEmpresarial_1);
		
		JMenuItem mntmSalir = new JMenuItem("Salir");
		mntmSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				
			}
		});
		mnArchivo.add(mntmSalir);
		
		JMenu mnAcciones = new JMenu("Acciones");
		menuBar.add(mnAcciones);
		
		JMenu mnDepositarCuenta = new JMenu("Depositar Cuenta");
		mnAcciones.add(mnDepositarCuenta);
		
		JMenuItem mntmCuentaNatural = new JMenuItem("Cuenta Natural");
		mnDepositarCuenta.add(mntmCuentaNatural);
		
		JMenuItem mntmCuentaEmpresarial = new JMenuItem("Cuenta Empresarial");
		mnDepositarCuenta.add(mntmCuentaEmpresarial);
		
		JMenu mnRetirarCuenta = new JMenu("Retirar Cuenta");
		mnAcciones.add(mnRetirarCuenta);
		
		JMenuItem mntmCuentaNatural_1 = new JMenuItem("Cuenta Natural");
		mnRetirarCuenta.add(mntmCuentaNatural_1);
		
		JMenuItem mntmCuentaEmpresarial_1 = new JMenuItem("Cuenta Empresarial");
		mnRetirarCuenta.add(mntmCuentaEmpresarial_1);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
}
