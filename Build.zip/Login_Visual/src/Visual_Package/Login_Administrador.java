package Visual_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import Datos_Trabajador.*;
import Datos_Administrador.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Login_Administrador extends JFrame 
{
	private JPanel contentPane;
	private JTextField txt_Usuario;
	private JPasswordField txt_Contrase�a;
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					Login_Administrador frame = new Login_Administrador();
					frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login_Administrador() 
	{
		setBounds(100, 100, 259, 255);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBienvenido = new JLabel("Administrador");
		lblBienvenido.setFont(new Font("Calisto MT", Font.BOLD, 25));
		lblBienvenido.setBounds(41, 11, 177, 31);
		contentPane.add(lblBienvenido);
		
		JLabel lblUsuario = new JLabel("Usuario:");
		lblUsuario.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		lblUsuario.setBounds(34, 53, 70, 21);
		contentPane.add(lblUsuario);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		lblContrasea.setBounds(10, 85, 94, 21);
		contentPane.add(lblContrasea);
		
		txt_Usuario = new JTextField();
		txt_Usuario.setBounds(124, 53, 105, 20);
		contentPane.add(txt_Usuario);
		txt_Usuario.setColumns(10);
		
		txt_Contrase�a = new JPasswordField();
		txt_Contrase�a.setBounds(124, 87, 105, 20);
		contentPane.add(txt_Contrase�a);
		
		JButton button_Ingresar = new JButton("Ingresar");
		button_Ingresar.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				char Clave1[] = txt_Contrase�a.getPassword();
				
				String ClaveUsuario1 = new String(Clave1);
				
				//Solo Cuenta Administrador 
				if (txt_Usuario.getText().equals("Administrador") && ClaveUsuario1.equals("admin")) 
				{
					//Enrutamiento a la Vista de Administrador
					JOptionPane.showMessageDialog(null, "Bienvenido\n" + "Has Ingresado Satisfactoriamente al Sistema"
					, "Mensaje de Bienvenida",JOptionPane.INFORMATION_MESSAGE);
					Datos_Administrador.MenuPrincipal formFormulario1 = new Datos_Administrador.MenuPrincipal();
					formFormulario1.setVisible(true);
					Login_Administrador.this.setVisible(false);
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Acceso denegado:\n"
		            + "Por favor ingrese un usuario y/o contrase�a correctos", "Acceso denegado",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_Ingresar.setFont(new Font("Segoe UI", Font.BOLD, 15));
		button_Ingresar.setBounds(10, 128, 94, 40);
		contentPane.add(button_Ingresar);
		
		JButton button_Salir = new JButton("Salir");
		button_Salir.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				JOptionPane.showConfirmDialog(null, "Realmente desea Salir del Sistema?", 
			    "Confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);
			}
		});
		button_Salir.setFont(new Font("Segoe UI", Font.BOLD, 15));
		button_Salir.setBounds(139, 128, 94, 40);
		contentPane.add(button_Salir);
		
		JLabel lbleresAdministrador = new JLabel("Si no eres Administrador ....");
		lbleresAdministrador.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lbleresAdministrador.setBounds(10, 179, 155, 14);
		contentPane.add(lbleresAdministrador);
		
		JLabel lblSirvaseLlamarAl = new JLabel("Sirvase Retornar al Inicio");
		lblSirvaseLlamarAl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				Login_Principal formFormulario1 = new Login_Principal();
				formFormulario1.setVisible(true);
				Login_Administrador.this.setVisible(false);
			}
		});
		lblSirvaseLlamarAl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSirvaseLlamarAl.setBounds(78, 196, 140, 9);
		contentPane.add(lblSirvaseLlamarAl);
	}
}
