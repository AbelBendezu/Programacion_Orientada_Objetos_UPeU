package Visual_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import Datos_Trabajador.*;
import Datos_Administrador.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Login_Principal extends JFrame 
{
	private JPanel contentPane;
	private JTextField txt_Usuario;
	private JPasswordField txt_Contrase�a;
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					Login_Principal frame = new Login_Principal();
					frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login_Principal() 
	{
		setBounds(100, 100, 259, 240);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBienvenido = new JLabel("Bienvenido");
		lblBienvenido.setFont(new Font("Calisto MT", Font.BOLD, 25));
		lblBienvenido.setBounds(55, 11, 130, 31);
		contentPane.add(lblBienvenido);
		
		JLabel lblUsuario = new JLabel("Usuario:");
		lblUsuario.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		lblUsuario.setBounds(34, 53, 70, 21);
		contentPane.add(lblUsuario);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		lblContrasea.setBounds(10, 85, 94, 21);
		contentPane.add(lblContrasea);
		
		txt_Usuario = new JTextField();
		txt_Usuario.setBounds(124, 53, 105, 20);
		contentPane.add(txt_Usuario);
		txt_Usuario.setColumns(10);
		
		txt_Contrase�a = new JPasswordField();
		txt_Contrase�a.setBounds(124, 87, 105, 20);
		contentPane.add(txt_Contrase�a);
		
		JButton button_Ingresar = new JButton("Ingresar");
		button_Ingresar.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				char Clave2[] = txt_Contrase�a.getPassword();

				String ClaveUsuario2 = new String(Clave2);
				
				if (txt_Usuario.getText().equals("Trabajador") && ClaveUsuario2.equals("trabaj")) 
				{
					//Enrutamenineto a la Vista de Trabajador
					JOptionPane.showMessageDialog(null,"Bienvenido\n" + "Has Ingresado Satisfactoriamente al Sistema"
					, "Mensaje de Bienvenida",JOptionPane.INFORMATION_MESSAGE);
					Datos_Trabajador.MenuPrincipal formFormulario2 = new Datos_Trabajador.MenuPrincipal();
					formFormulario2.setVisible(true);
					Login_Principal.this.setVisible(false);
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Acceso denegado:\n"
		            + "Por favor ingrese un usuario y/o contrase�a correctos", "Acceso denegado",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_Ingresar.setFont(new Font("Segoe UI", Font.BOLD, 15));
		button_Ingresar.setBounds(10, 128, 94, 40);
		contentPane.add(button_Ingresar);
		
		JButton button_Salir = new JButton("Salir");
		button_Salir.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				JOptionPane.showConfirmDialog(null, "Realmente desea Salir del Sistema?", 
			    "Confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);
			}
		});
		button_Salir.setFont(new Font("Segoe UI", Font.BOLD, 15));
		button_Salir.setBounds(139, 128, 94, 40);
		contentPane.add(button_Salir);
		
		JLabel lbleresAdministrador = new JLabel("\u00BFEres Administrador?");
		lbleresAdministrador.setBounds(20, 179, 144, 14);
		contentPane.add(lbleresAdministrador);
		
		JLabel Label_IngAdmin = new JLabel("!Click Aqui!");
		Label_IngAdmin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				Login_Administrador formFormulario1 = new Login_Administrador();
				formFormulario1.setVisible(true);
				Login_Principal.this.setVisible(false);
			}
		});
		Label_IngAdmin.setBounds(149, 179, 65, 14);
		contentPane.add(Label_IngAdmin);
	}
}
