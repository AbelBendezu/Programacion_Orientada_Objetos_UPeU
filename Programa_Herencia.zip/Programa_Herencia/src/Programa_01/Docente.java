
package Programa_01;

import java.util.Scanner;

public class Docente 
{
        //Datos para la clase Docente
        private String Nombre;
        private String Ap_Paterno;
        private String Ap_Materno;
        private String Facultad;
        private String Escuela_Profesional;
        private String Tipo_Trabajador;
        private double Hora_Ingreso;
        private double Hora_Salida;
        //Metodo de Encapsulamiento Get & Set
        //Comienzo del Metodo
        //Valor Nombre
        public String getNombre() 
        {
            return Nombre;
        }
        public void setNombre(String Nombre) 
        {
            this.Nombre = Nombre;
        }
        //Valor Ap_Paterno
        public String getAp_Paterno() 
        {
            return Ap_Paterno;
        }
        public void setAp_Paterno(String Ap_Paterno) 
        {
            this.Ap_Paterno = Ap_Paterno;
        }
        //Valor Ap_Materno
        public String getAp_Materno() 
        {
            return Ap_Materno;
        }
        public void setAp_Materno(String Ap_Materno) 
        {
            this.Ap_Materno = Ap_Materno;
        }
        //Valor Facultad
        public String getFacultad() 
        {
            return Facultad;
        }
        public void setFacultad(String Facultad) 
        {
            this.Facultad = Facultad;
        }
        //Valor Escuela_Profesional
        public String getEscuela_Profesional() 
        {
            return Escuela_Profesional;
        }
        public void setEscuela_Profesional(String Escuela_Profesional) 
        {
            this.Escuela_Profesional = Escuela_Profesional;
        }
        //Valor Tipo_Trabajador
        public String getTipo_Trabajador() 
        {
            return Tipo_Trabajador;
        }
        public void setTipo_Trabajador(String Tipo_Trabajador) 
        {
            this.Tipo_Trabajador = Tipo_Trabajador;
        }
        //Valor Hora_Ingreso
        public double getHora_Ingreso() 
        {
            return Hora_Ingreso;
        }
        public void setHora_Ingreso(double Hora_Ingreso) 
        {
            this.Hora_Ingreso = Hora_Ingreso;
        }
        //Valor Hora_Salida
        public double getHora_Salida() 
        {
            return Hora_Salida;
        }
        public void setHora_Salida(double Hora_Salida) 
        {
            this.Hora_Salida = Hora_Salida;
        }
        //Fin del Metodo de Encapsulamiento para la Clase Docente
        //Constructores
        public Docente()
        {
            
        }
        public Docente(String Nom, String Ap_pa, String Ap_ma, String Facu, String Escu, String Ti_trab, double Ho_in, double Ho_sa)
        {
         this.setNombre(Nom);
         this.setAp_Paterno(Ap_pa);
         this.setAp_Materno(Ap_ma);
         this.setFacultad(Facu);
         this.setEscuela_Profesional(Escu);
         this.setTipo_Trabajador(Ti_trab);
         this.setHora_Ingreso(Ho_in);
         this.setHora_Salida(Ho_sa);
        }
        public void LeerDatos()
        {
         Scanner lector = new Scanner(System.in);
         System.out.println("Ingrese Nombre:");
         this.setNombre(lector.next());
         System.out.println("Ingrese Apellido Paterno:");
         this.setAp_Paterno(lector.next());
         System.out.println("Ingrese Apellido Materno:");
         this.setAp_Materno(lector.next());
         System.out.println("Ingrese Facultad:");
         this.setFacultad(lector.next());
         System.out.println("Ingrese Escuela Profesional:");
         this.setEscuela_Profesional(lector.next());
         System.out.println("Ingrese Tipo de Trabajador:");
         this.setTipo_Trabajador(lector.next());
         System.out.println("Ingrese Hora de Ingreso:");
         this.setHora_Ingreso(lector.nextDouble());
         System.out.println("Ingrese Hora de Salida:");
         this.setHora_Salida(lector.nextDouble());
        }
        public void ImprimirDatos()
        {
       System.out.println("Nombre:" + this.getNombre());
       System.out.println("Apellido Paterno:" + this.getAp_Paterno());
       System.out.println("Apellido Materno:" + this.getAp_Materno());
       System.out.println("Facultad:" + this.getFacultad());
       System.out.println("Escuela Profesional:" + this.getEscuela_Profesional());
       System.out.println("Tipo de Trabajador:" + this.getTipo_Trabajador());
       System.out.println("Hora de Ingreso:" + this.getHora_Ingreso());
       System.out.println("Hora de Salida:" + this.getHora_Salida());
        }  
            }
