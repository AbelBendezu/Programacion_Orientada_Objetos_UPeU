
package Programa_01;

import java.util.Scanner;

public class Estudiante 
    {
        //Datos para la clase Estudiante 
        private String Nombre;
        private String Ap_Paterno;
        private String Ap_Materno;
        private String Facultad;
        private String Escuela_Profesional;
        private int Codigo_Estudiante;
        private int Fecha_Nacimiento;
        private int Numero_Celular;
        //Metodo de Encapsulamiento Get & Set
        //Comienzo del Metodo
        //Valor Nombre
        public String getNombre() 
        {
            return Nombre;
        }
        public void setNombre(String Nombre) 
        {
            this.Nombre = Nombre;
        }
        //Valor Ap_Paterno
        public String getAp_Paterno() 
        {
            return Ap_Paterno;
        }
        public void setAp_Paterno(String Ap_Paterno) 
        {
            this.Ap_Paterno = Ap_Paterno;
        }
        //Valor Ap_Materno
        public String getAp_Materno() 
        {
            return Ap_Materno;
        }
        public void setAp_Materno(String Ap_Materno) 
        {
            this.Ap_Materno = Ap_Materno;
        }
        //Valor Facultad
        public String getFacultad() 
        {
            return Facultad;
        }
        public void setFacultad(String Facultad) 
        {
            this.Facultad = Facultad;
        }
        //Valor Escuela_Profesional
        public String getEscuela_Profesional()
        {
            return Escuela_Profesional;
        }
        public void setEscuela_Profesional(String Escuela_Profesional)
        {
            this.Escuela_Profesional = Escuela_Profesional;
        }
        //Valor Codigo_Estudiante
        public int getCodigo_Estudiante() 
        {
            return Codigo_Estudiante;
        }
        public void setCodigo_Estudiante(int Codigo_Estudiante) 
        {
            this.Codigo_Estudiante = Codigo_Estudiante;
        }
        //Valor Fecha_Nacimiento
        public int getFecha_Nacimiento() 
        {
            return Fecha_Nacimiento;
        }
        public void setFecha_Nacimiento(int Fecha_Nacimiento) 
        {
            this.Fecha_Nacimiento = Fecha_Nacimiento;
        }
        //Valor Numero_Celular
        public int getNumero_Celular() 
        {
            return Numero_Celular;
        }
        public void setNumero_Celular(int Numero_Celular) 
        {
            this.Numero_Celular = Numero_Celular;
        }
        //Fin del Metodo de Encapsulamiento para la Clase Docente
        //Comienzo de Constructores
        public Estudiante()
        {
            
        }
        public Estudiante(String Nom, String Ap_pa, String Ap_ma, String Facu, String Escu, int Cod, int Fe_na, int Num_cel)
        {
            this.setNombre(Nom);
            this.setAp_Paterno(Ap_pa);
            this.setAp_Materno(Ap_ma);
            this.setFacultad(Facu);
            this.setEscuela_Profesional(Escu);
            this.setCodigo_Estudiante(Cod);
            this.setFecha_Nacimiento(Fe_na);
            this.setNumero_Celular(Num_cel);
        }
        public void LeerDatos()
    {
       Scanner lector = new Scanner(System.in);
       System.out.println("Ingrese Nombre:");
       this.setNombre(lector.next());
       System.out.println("Ingrese Apellido Paterno:");
       this.setAp_Paterno(lector.next());
       System.out.println("Ingrese Apellido Materno:");
       this.setAp_Materno(lector.next());
       System.out.println("Ingrese Facultad:");
       this.setFacultad(lector.next());
       System.out.println("Ingrese Escuela Profesional:");
       this.setEscuela_Profesional(lector.next());
       System.out.println("Ingrese Codigo de Estudiante:");
       this.setCodigo_Estudiante(lector.nextInt());
       System.out.println("Ingrese Fecha de Nacimiento:");
       this.setFecha_Nacimiento(lector.nextInt());
       System.out.println("Ingrese Numero de Celular:");
       this.setNumero_Celular(lector.nextInt());
    }
        public void ImprimirDatos()
    {
       System.out.println("Nombre:" + this.getNombre());
       System.out.println("Apellido Paterno:" + this.getAp_Paterno());
       System.out.println("Apellido Materno:" + this.getAp_Materno());
       System.out.println("Facultad:" + this.getFacultad());
       System.out.println("Escuela Profesional:" + this.getEscuela_Profesional());
       System.out.println("Codigo Estudiante:" + this.getCodigo_Estudiante());
       System.out.println("Fecha de Nacimiento:" + this.getFecha_Nacimiento());
       System.out.println("Numero de Celular:" + this.getNumero_Celular());
    }  
        }