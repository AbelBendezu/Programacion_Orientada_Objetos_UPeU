
package Programa_01;

import java.util.Scanner;

public class Menu 
{
    public static void main(String[] args)
        {
        Scanner lector = new Scanner(System.in);
        boolean Exit = false;
        int opcion;
        while (!Exit) 
        {
            System.out.println("======================================");
            System.out.println("=================Menu=================");
            System.out.println("======================================");
            System.out.println("======1. Sistema Docente==============");
            System.out.println("======2. Sistema Estudiante===========");
            System.out.println("======3. Salir========================");
            System.out.println("======================================");
            System.out.println("");
                
                opcion = lector.nextInt();
 
                switch (opcion) 
                {
                    case 1:
                        System.out.println("Bienvenido al Sistema Docente");
                        break;
                    case 2:
                        System.out.println("Bienvenido al Sistema Estudiante 2");
                        break;
                    case 3:
                        Exit = true;
                        break;
                    default:
                        System.out.println("Solo números entre 1 y 3");
                }
        }
    }
    public class Seleccion_Menu1 extends Docente
    {
        
    }
    public class Seleccion_Menu2 extends Estudiante
    {
        
    }
}
