package BD_Info;

import java.util.Scanner;

public class Automovil 
{
    //Ingresado de Datos al Algoritmo
    private String Placa;
    private String Marca;
    private String Modelo;
    private Propietario propietario; //Clase - Dato //Clase Propietario - Dato Propietario
    private String TipoMotor;
    int NumEjes;
    //Metodo Set&Get
    public String getPlaca()
    {
        return Placa;
    }
    public void setPlaca(String Placa) 
    {
        this.Placa = Placa;
    }
    public String getMarca() 
    {
        return Marca;
    }
    public void setMarca(String Marca) 
    {
        this.Marca = Marca;
    }
    public String getModelo() 
    {
        return Modelo;
    }
    public void setModelo(String Modelo)
    {
        this.Modelo = Modelo;
    }
    public Propietario getPropietario()
    {
        return propietario;
    }
    public void setPropietario(Propietario propietario)
    {
        this.propietario = propietario;
    }
    public String getTipoMotor() 
    {
        return TipoMotor;
    }
    public void setTipoMotor(String TipoMotor)
    {
        this.TipoMotor = TipoMotor;
    }
    public int getNumEjes() 
    {
        return NumEjes;
    }
    public void setNumEjes(int NumEjes) 
    {
        this.NumEjes = NumEjes;
    }
    //Metodos y Constructores
    public Automovil ()
    {
        this.setPlaca         ("");
        this.setMarca         ("");
        this.setModelo        ("");
        this.setPropietario   (propietario);
        this.setTipoMotor     ("");
    }
    public Automovil (String placa, String marca, String modelo, Propietario Propietario, String Motor)
    {
        this.setPlaca(placa);
        this.setMarca(marca);
        this.setModelo(modelo);
        this.setPropietario(Propietario);
        this.setTipoMotor(Motor);
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese Numero de Placa: ");
        this.setPlaca(lector.next());
        System.out.println("Ingrese Nombre de Marca: ");
        this.setMarca(lector.next());
        System.out.println("Ingrese Numero de Modelo: ");
        this.setModelo(lector.next());
        System.out.println("Ingrese Nombre Propietario: ");
        this.setPropietario(propietario);
        System.out.println("Ingrese Tipo de Motor: ");
        this.setTipoMotor(lector.next());
    }
    public void Imprimir()
    {
        System.out.println("Numero de Placa: " + this.getPlaca());
        System.out.println("Marca: " + this.getMarca());
        System.out.println("Modelo: " + this.getModelo());
        System.out.println("Nombre de Propietario: " + this.propietario);
        System.out.println("Tipó de Motor: " + this.getTipoMotor());
    }
}
