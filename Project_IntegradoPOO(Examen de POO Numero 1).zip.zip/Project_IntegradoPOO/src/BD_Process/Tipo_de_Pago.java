
package BD_Process;

import BD_Info.Propietario;
public class Tipo_de_Pago 
{
    public class Metodo_Factura extends Propietario
    {
        int         NumFactura;
        Propietario TitularMov;
        int         IDRevision;
        String      FechaEmision;
        int         RUC_Cliente;
    }
    public class Metodo_Boleta extends Propietario
    {
        int         NumBoleta;
        Propietario TitutalMov;
        int         Direccion;
        String      FechaEmision;
        String      DocumentoIdentidad;
    }
}
