package BD_Algoritmo;
import BD_Operaciones.opCalcularCobranza;
import BD_Operaciones.opSalario;
import BD_Operaciones.opEvaluarAprobacion;
import BD_Operaciones.opRevisarAutomovil;
import BD_Operaciones.opComision;
import java.util.Scanner;

public class Menu_Principal 
{
    public static void main(String[] args) 
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("=====Bienvenido al Menu======");
        System.out.println("Calcular Salario del Tecnico:");
        int n1 = 0;
        n1 = (int) opSalario.CalcularSueldo();
        System.out.println("=============================");
        System.out.println("Evaluar Aprobacion del Auto");
        int n2 = 0;
        n2 = (int) opEvaluarAprobacion.EvaluarAprobacion();
        System.out.println("=============================");
        System.out.println("Revisar Automovil");
        int n3 = 0;
        n3 = (int) opRevisarAutomovil.LeerDatos();
        n3 = (int) opRevisarAutomovil.ImprimirDatos();
        System.out.println("=============================");
        System.out.println("Calcular Cobranza: ");
        int n4 = 0;
        n4 = (int) opCalcularCobranza.CalcularCobranza();
        System.out.println("=============================");
        System.out.println("Calcular Comision: ");
        int n5 = 0;
        n5 = (int) opComision.Comision.LeerDatos();
        n5 = (int) opComision.Comision.ImprimirDatos();
        System.out.println("=============================");
    }
}
