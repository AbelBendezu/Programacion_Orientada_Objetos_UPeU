
package BD_Algoritmo;

import BD_Informacion.infoPropietario;
import java.util.Date;
import java.util.Scanner;

public class algFactura
{
    public static class Factura
    {
        static private int              NroFactura;
        static private infoPropietario  Titularmov;
        static private int              ID_Revision;
        static private Date             Fecha_Emision;
        static private int              RUC_Cliente;
        //Metodo Set&Get
        public static int getNroFactura() 
        {
            return NroFactura;
        }
        public static void setNroFactura(int NroFactura) 
        {
            Factura.NroFactura = NroFactura;
        }
        public static infoPropietario getTitularmov() 
        {
            return Titularmov;
        }
        public static void setTitularmov(infoPropietario Titularmov)
        {
            Factura.Titularmov = Titularmov;
        }
        public static int getID_Revision() 
        {
            return ID_Revision;
        }
        public static void setID_Revision(int ID_Revision)
        {
            Factura.ID_Revision = ID_Revision;
        }
        public static Date getFecha_Emision() 
        {
            return Fecha_Emision;
        }
        public static void setFecha_Emision(Date Fecha_Emision)
        {
            Factura.Fecha_Emision = Fecha_Emision;
        }
        public static int getRUC_Cliente() 
        {
            return RUC_Cliente;
        }
        public static void setRUC_Cliente(int RUC_Cliente)
        {
            Factura.RUC_Cliente = RUC_Cliente;
        }
        //MEtodos y COnstructores
        public Factura() 
        {
            Factura.setNroFactura(0);
            Factura.setTitularmov(Titularmov);
            Factura.setID_Revision(0);
            Factura.setFecha_Emision(Fecha_Emision);
            Factura.setRUC_Cliente(0);
        }
        public Factura(int nroFactura, infoPropietario Titularmov, int id_Revision, 
                       Date fecha_Emision, int ruc_Cliente)
        {
            Factura.setNroFactura(nroFactura);
            Factura.setTitularmov(Titularmov);
            Factura.setID_Revision(id_Revision);
            Factura.setFecha_Emision(fecha_Emision);
            Factura.setRUC_Cliente(ruc_Cliente);
        }
        public void LeerDatos()
        {
            Scanner lector = new Scanner(System.in);
            System.out.println("Ingrese Numero de Factura: ");
            Factura.setNroFactura(lector.nextInt());
            System.out.println("Ingrese Titular de Movilidad: ");
            Factura.setTitularmov(Titularmov);
            System.out.println("Ingrese ID de Revision: ");
            Factura.setID_Revision(lector.nextInt());
            System.out.println("Ingrese Fecha de Emision: ");
            Factura.setFecha_Emision(Fecha_Emision);
            System.out.println("Ingrese RUC del Cliente: ");
            Factura.setRUC_Cliente(lector.nextInt());
        }
        public void ImprimirDatos()
        {
            System.out.println("Numero de Factura: " + Factura.getNroFactura());
            System.out.println("Titular de Movilidad: " + Factura.getTitularmov());
            System.out.println("ID de Revision: " + Factura.getID_Revision());
            System.out.println("Fecha de Emision: " + Factura.getFecha_Emision());
            System.out.println("RUC del Cliente: " + Factura.getRUC_Cliente());
        }
    }
}
