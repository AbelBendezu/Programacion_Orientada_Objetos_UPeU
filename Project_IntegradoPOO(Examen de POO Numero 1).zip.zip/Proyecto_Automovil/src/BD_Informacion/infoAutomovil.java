
package BD_Informacion;

import java.util.Scanner;

public class infoAutomovil 
{
    public static class Automovil
    {
    //Ingresado de Datos al Algoritmo
    static private String           Placa;
    static private String           Marca;
    static private String           Modelo;
    static private infoPropietario  Propietario;
    static private String           TipoMotor;
    static private int              NumEjes;
        //Codigos Set&Get
        public static String getPlaca() 
        {
            return Placa;
        }
        public static void setPlaca(String Placa) 
        {
            Automovil.Placa = Placa;
        }
        public static String getMarca() 
        {
            return Marca;
        }
        public static void setMarca(String Marca)
        {
            Automovil.Marca = Marca;
        }
        public static String getModelo() 
        {
            return Modelo;
        }
        public static void setModelo(String Modelo) 
        {
            Automovil.Modelo = Modelo;
        }
        public static infoPropietario getPropietario()
        {
            return Propietario;
        }
        public static void setPropietario(infoPropietario Propietario) 
        {
            Automovil.Propietario = Propietario;
        }
        public static String getTipoMotor() 
        {
            return TipoMotor;
        }
        public static void setTipoMotor(String TipoMotor) 
        {
            Automovil.TipoMotor = TipoMotor;
        }
        public static int getNumEjes() 
        {
            return NumEjes;
        }

        public static void setNumEjes(int NumEjes)
        {
            Automovil.NumEjes = NumEjes;
        }
        //Metodos y Constructores
    public Automovil() 
        {
             Automovil.setPlaca("");
             Automovil.setMarca("");
             Automovil.setModelo("");
             Automovil.setPropietario(Propietario);
             Automovil.setTipoMotor("");
             Automovil.setNumEjes(0);
        }
    public Automovil(String placa, String marca, String modelo, infoPropietario propietario,
                     String tipoMotor, int numEjes)
        {
             Automovil.setPlaca(placa);
             Automovil.setMarca(marca);
             Automovil.setModelo(modelo);
             Automovil.setPropietario(propietario);
             Automovil.setTipoMotor(tipoMotor);
             Automovil.setNumEjes(numEjes);
        }
    public void LeerDatos()
        {
             Scanner lector = new Scanner(System.in);
             System.out.println("Ingrese Numero de Placa: ");
             Automovil.setPlaca(lector.next());
             System.out.println("Ingrese Marca del Automovil: ");
             Automovil.setMarca(lector.next());
             System.out.println("Ingrese Modelo del Automovil: ");
             Automovil.setModelo(lector.next());
             System.out.println("Ingrese Nombre del Propietario: ");
             Automovil.setPropietario(Automovil.Propietario);
             System.out.println("Ingrese Tipo de Motor: ");
             Automovil.setTipoMotor(lector.next());
        }
    public void ImprimirDatos()
        {
             System.out.println("Numero de Placa: " + Automovil.getPlaca());
             System.out.println("Marca de Automovil: " + Automovil.getMarca());
             System.out.println("Modelo de Automovil: " + Automovil.getModelo());
             System.out.println("Nombre del Propietario: " + Automovil.getPropietario());
             System.out.println("Tipo de Motor: " + Automovil.getTipoMotor());
        }
    public static class PuntosRevision
        {
             static public int llantas;
             static public int engranaje;
             static public int nivel_frenos;
             static public int nivel_liquidos;
             static public int Señalizacion_optica;
            //Metodo Set&Get
            public static int getLlantas() 
            {
                return llantas;
            }
            public static void setLlantas(int llantas) 
            {
                PuntosRevision.llantas = llantas;
            }
            public static int getEngranaje() 
            {
                return engranaje;
            }
            public static void setEngranaje(int engranaje)
            {
                PuntosRevision.engranaje = engranaje;
            }
            public static int getNivel_frenos() 
            {
                return nivel_frenos;
            }
            public static void setNivel_frenos(int nivel_frenos) 
            {
                PuntosRevision.nivel_frenos = nivel_frenos;
            }
            public static int getNivel_liquidos() 
            {
                return nivel_liquidos;
            }
            public static void setNivel_liquidos(int nivel_liquidos) 
            {
                PuntosRevision.nivel_liquidos = nivel_liquidos;
            }
            public static int getSeñalizacion_optica() 
            {
                return Señalizacion_optica;
            }
            public static void setSeñalizacion_optica(int Señalizacion_optica)
            {
                PuntosRevision.Señalizacion_optica = Señalizacion_optica;
            }
            //Constructores
            public PuntosRevision() 
            {
                PuntosRevision.setLlantas(0);
                PuntosRevision.setEngranaje(0);
                PuntosRevision.setNivel_frenos(0);
                PuntosRevision.setNivel_liquidos(0);
                PuntosRevision.setSeñalizacion_optica(0);                
            }
            public PuntosRevision(int llantas, int engranaje, int nivel_frenos, 
                                  int nivel_liquidos,int señalizacion_optica)
            {
                PuntosRevision.setLlantas(llantas);
                PuntosRevision.setEngranaje(engranaje);
                PuntosRevision.setNivel_frenos(nivel_frenos);
                PuntosRevision.setNivel_liquidos(nivel_liquidos);
                PuntosRevision.setSeñalizacion_optica(señalizacion_optica);
            }
            public void LeerDatos()
            {
                Scanner lector = new Scanner(System.in);
                System.out.println("Ingrese el Nivel de Llantas: ");
                PuntosRevision.setLlantas(lector.nextInt());
                System.out.println("Ingrese el Estado de los Engranajes: ");
                PuntosRevision.setEngranaje(lector.nextInt());
                System.out.println("Ingrese el Nivel de los Frenos: ");
                PuntosRevision.setNivel_frenos(lector.nextInt());
                System.out.println("Ingrese el Nivel de los Liquidos: ");
                PuntosRevision.setNivel_liquidos(lector.nextInt());
                System.out.println("Ingrese el Estado de las Señalizaciones Opticas: ");
                PuntosRevision.setSeñalizacion_optica(lector.nextInt());
            }
            public void ImprimirDatos()
            {
                System.out.println("Nivel de Llantas: " + PuntosRevision.getLlantas());
                System.out.println("Estado de Engranajes: " + PuntosRevision.getEngranaje());
                System.out.println("Nivel de Frenos: " + PuntosRevision.getNivel_frenos());
                System.out.println("Nivel de Liquidos: " + PuntosRevision.getNivel_liquidos());
                System.out.println("Estado de Señalizacion Optica: " + PuntosRevision.getSeñalizacion_optica());
            }
        }
    }
}