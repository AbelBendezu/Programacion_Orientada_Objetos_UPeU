package BD_Informacion;

import java.util.Scanner;

public class infoPropietario 
{
    public static class Propietario
    {
        //Ingreso de Datos al Algoritmo
        static private String DNI;
        static private String Nombre;
        static private String ApPaterno;
        static private String ApMaterno;
        static private String RUC;
        static private int    Edad;
        //Metodo Set&Get
        public static String getDNI() 
        {
            return DNI;
        }
        public static void setDNI(String DNI)
        {
            Propietario.DNI = DNI;
        }
        public static String getNombre() 
        {
            return Nombre;
        }
        public static void setNombre(String Nombre) 
        {
            Propietario.Nombre = Nombre;
        }
        public static String getApPaterno()
        {
            return ApPaterno;
        }
        public static void setApPaterno(String ApPaterno)
        {
            Propietario.ApPaterno = ApPaterno;
        }
        public static String getApMaterno() 
        {
            return ApMaterno;
        }
        public static void setApMaterno(String ApMaterno)
        {
            Propietario.ApMaterno = ApMaterno;
        }
        public static String getRUC() 
        {
            return RUC;
        }
        public static void setRUC(String RUC) 
        {
            Propietario.RUC = RUC;
        }
        public static int getEdad() 
        {
            return Edad;
        }
        public static void setEdad(int Edad)
        {
            Propietario.Edad = Edad;
        }
        //Metodos y Constructores
        public Propietario()
        {
            Propietario.setDNI("");
            Propietario.setNombre("");
            Propietario.setApPaterno("");
            Propietario.setApMaterno("");
            Propietario.setRUC("");
            Propietario.setEdad(0);
        }
        public Propietario(String dni, String nombre, String apPaterno, String apMaterno,
                           String ruc, String edad)
        {
            Propietario.setDNI(dni);
            Propietario.setNombre(nombre);
            Propietario.setApPaterno(apPaterno);
            Propietario.setApMaterno(apMaterno);
            Propietario.setRUC(ruc);
            Propietario.setEdad(Edad);
        }
        public void LeerDatos()
        {
            Scanner lector = new Scanner (System.in);
            System.out.println("Ingrese Numero de DNI: ");
            Propietario.setDNI(lector.next());
            System.out.println("Ingrese Nombre(s): ");
            Propietario.setNombre(lector.next());
            System.out.println("Ingrese Apellido Paterno: ");
            Propietario.setApPaterno(lector.next());
            System.out.println("Ingrese Apellido Materno: ");
            Propietario.setApMaterno(lector.next());
            System.out.println("Ingrese Numero de RUC: ");
            Propietario.setRUC(lector.next());
            System.out.println("Ingrese Edad: ");
            Propietario.setEdad(lector.nextInt());
        }
        public void ImprimirDatos()
        {
            System.out.println("Numero DNI: " + Propietario.getNombre());
            System.out.println("Nombre(s): " + Propietario.getNombre());
            System.out.println("Apellido Paterno: " + Propietario.getApPaterno());
            System.out.println("Apellido Naterno: " + Propietario.getApMaterno());
            System.out.println("Numero de RUC: " + Propietario.getRUC());
            System.out.println("Edad: " + Propietario.getEdad());
        }
    }
}
