
package BD_Informacion;

import BD_Informacion.infoTecnico;
import java.util.Date;
import java.util.Scanner;

public class infoRevision
{
    public static class Revision
    {
        static private int          ID_Revision;
        static private int          ID_Tecnico;
        static private Date         Fecha_Revision;
        static private infoTecnico  Tecnico_Asignado;
        static private Object       Auto_Revisado;
        static public  double       Tiempo_Planificado;
        static public  double       Tiempo_Revision_Utilizado;
        static private int          Tipo_Auto_Revisar;
        static private boolean      Resultado_Revision;
        //Metodo Set&Get
        public static int getID_Revision() 
        {
            return ID_Revision;
        }
        public static void setID_Revision(int ID_Revision) 
        {
            Revision.ID_Revision = ID_Revision;
        }
        public static int getID_Tecnico() 
        {
            return ID_Tecnico;
        }
        public static void setID_Tecnico(int ID_Tecnico) 
        {
            Revision.ID_Tecnico = ID_Tecnico;
        }
        public static Date getFecha_Revision() 
        {
            return Fecha_Revision;
        }
        public static void setFecha_Revision(Date Fecha_Revision)
        {
            Revision.Fecha_Revision = Fecha_Revision;
        }
        public static infoTecnico getTecnico_Asignado() 
        {
            return Tecnico_Asignado;
        }
        public static void setTecnico_Asignado(infoTecnico Tecnico_Asignado) 
        {
            Revision.Tecnico_Asignado = Tecnico_Asignado;
        }
        public static Object getAuto_Revisado()
        {
            return Auto_Revisado;
        }
        public static void setAuto_Revisado(Object Auto_Revisado) 
        {
            Revision.Auto_Revisado = Auto_Revisado;
        }
        public static double getTiempo_Planificado() 
        {
            return Tiempo_Planificado;
        }
        public static void setTiempo_Planificado(double Tiempo_Planificado) 
        {
            Revision.Tiempo_Planificado = Tiempo_Planificado;
        }
        public static double getTiempo_Revision_Utilizado() 
        {
            return Tiempo_Revision_Utilizado;
        }
        public static void setTiempo_Revision_Utilizado(double Tiempo_Revision_Utilizado) 
        {
            Revision.Tiempo_Revision_Utilizado = Tiempo_Revision_Utilizado;
        }
        public static int getTipo_Auto_Revisar() 
        {
            return Tipo_Auto_Revisar;
        }
        public static void setTipo_Auto_Revisar(int Tipo_Auto_Revisar) 
        {
            Revision.Tipo_Auto_Revisar = Tipo_Auto_Revisar;
        }
        public static boolean isResultado_Revision() 
        {
            return Resultado_Revision;
        }
        public static void setResultado_Revision(boolean Resultado_Revision) 
        {
            Revision.Resultado_Revision = Resultado_Revision;
        }
        //Metodos y Constructores
        public Revision() 
        {
            Revision.setID_Revision(0);
            Revision.setID_Tecnico(0);
            Revision.setFecha_Revision(Fecha_Revision);
            Revision.setTecnico_Asignado(Tecnico_Asignado);
            Revision.setAuto_Revisado("");
            Revision.setTiempo_Planificado(0);
            Revision.setTiempo_Revision_Utilizado(0);
            Revision.setTipo_Auto_Revisar(0);
            Revision.setResultado_Revision(Resultado_Revision);
        }
        public Revision(int id_Revision, int id_Tecnico, Date fecha_Revision, 
                        infoTecnico tecnico_asignado, Object auto_Revisado, double tiempo_Plan,
                        double tiempo_Rev_Util, int tipo_Auto, boolean resultado_Rev)
        {
            Revision.setID_Revision(id_Revision);
            Revision.setID_Tecnico(id_Tecnico);
            Revision.setFecha_Revision(fecha_Revision);
            Revision.setTecnico_Asignado(tecnico_asignado);
            Revision.setAuto_Revisado(auto_Revisado);
            Revision.setTiempo_Planificado(tiempo_Plan);
            Revision.setTiempo_Revision_Utilizado(tiempo_Rev_Util);
            Revision.setTipo_Auto_Revisar(tipo_Auto);
            Revision.setResultado_Revision(resultado_Rev);
        }
        public void LeerDatos()
        {
            Scanner lector = new Scanner(System.in);
            System.out.println("Ingrese el ID de Revision: ");
            Revision.setID_Revision(lector.nextInt());
            System.out.println("Ingrese el ID del Tecnico: ");
            Revision.setID_Tecnico(lector.nextInt());
            System.out.println("Ingrese la Fecha de Revision: ");
            Revision.setFecha_Revision(Fecha_Revision);
            System.out.println("Ingrese el Tecnico Asignado: ");
            Revision.setTecnico_Asignado(Tecnico_Asignado);
            System.out.println("Ingrese el Auto Revisado: ");
            Revision.setAuto_Revisado(lector.next());
            System.out.println("Ingrese el Tiempo Planificado: ");
            Revision.setTiempo_Planificado(lector.nextDouble());
            System.out.println("Ingrese el Tiempo Utilizado: ");
            Revision.setTiempo_Revision_Utilizado(lector.nextDouble());
            System.out.println("Ingrese el Tipo de Auto a Revisar: ");
            Revision.setTipo_Auto_Revisar(lector.nextInt());
            System.out.println("Ingrese el Resultado de la Revision: ");
            Revision.setResultado_Revision(Resultado_Revision);
        }
        public void ImprimirDatos()
        {
            System.out.println("ID de Revision: " + Revision.getID_Revision());
            System.out.println("ID del Tecnico: " + Revision.getID_Tecnico());
            System.out.println("Fecha de Revision: " + Revision.getFecha_Revision());
            System.out.println("Tecnico Asignado: " + Revision.getTecnico_Asignado());
            System.out.println("Auto Revisado: " + Revision.getAuto_Revisado());
            System.out.println("Tiempo Planificado: " + Revision.getTiempo_Planificado());
            System.out.println("Tiempo Utilizado: " + Revision.getTiempo_Revision_Utilizado());
            System.out.println("Tipo de Auto a Revisar: " + Revision.getTipo_Auto_Revisar());
            System.out.println("Resultado de la Revision: " + Revision.isResultado_Revision());
        }
    }
}
