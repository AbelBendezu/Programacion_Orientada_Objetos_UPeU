package BD_Informacion;

import java.util.Scanner;

public class infoTecnico 
{
    public static class Tecnico
    {
        //Ingreso de datos al Algoritmo
        static private int      IDTecnico;
        static private String   Nombre;
        static private String   ApPaterno;
        static private String   ApMaterno;
        static private String   Especialidad;
        static private double   Sueldo;
        static private double   Comision;
        //Metodo Set&Get
        public static int getIDTecnico() 
        {
            return IDTecnico;
        }
        public static void setIDTecnico(int IDTecnico)
        {
            Tecnico.IDTecnico = IDTecnico;
        }
        public static String getNombre() 
        {
            return Nombre;
        }
        public static void setNombre(String Nombre) 
        {
            Tecnico.Nombre = Nombre;
        }
        public static String getApPaterno() 
        {
            return ApPaterno;
        }
        public static void setApPaterno(String ApPaterno) 
        {
            Tecnico.ApPaterno = ApPaterno;
        }
        public static String getApMaterno() 
        {
            return ApMaterno;
        }
        public static void setApMaterno(String ApMaterno)
        {
            Tecnico.ApMaterno = ApMaterno;
        }
        public static String getEspecialidad() 
        {
            return Especialidad;
        }
        public static void setEspecialidad(String Especialidad)
        {
            Tecnico.Especialidad = Especialidad;
        }
        public static double getSueldo() 
        {
            return Sueldo;
        }
        public static void setSueldo(double Sueldo) 
        {
            Tecnico.Sueldo = Sueldo;
        }
        public static double getComision()
        {
            return Comision;
        }
        public static void setComision(double Comision) 
        {
            Tecnico.Comision = Comision;
        }
        //Metods y Constructores
        public Tecnico() 
        {
            Tecnico.setIDTecnico(0);
            Tecnico.setNombre("");
            Tecnico.setApPaterno("");
            Tecnico.setApMaterno("");
            Tecnico.setEspecialidad("");
            Tecnico.setSueldo(0);
            Tecnico.setComision(0);
        }
        public Tecnico(int idTecnico, String nombre, String apPaterno, String apMaterno,
                       String especialidad, double sueldo, double comision)
        {
            Tecnico.setIDTecnico(idTecnico);
            Tecnico.setNombre(nombre);
            Tecnico.setApPaterno(apPaterno);
            Tecnico.setApMaterno(apMaterno);
            Tecnico.setEspecialidad(especialidad);
            Tecnico.setSueldo(sueldo);
            Tecnico.setComision(comision);
        }
        public void LeerDatos()
        {
            Scanner lector = new Scanner(System.in);
            System.out.println("Ingrese ID Tecnico: ");
            Tecnico.setIDTecnico(lector.nextInt());
            System.out.println("Ingrese Nombre(s): ");
            Tecnico.setNombre(lector.next());
            System.out.println("Ingrese Apellido Paterno: ");
            Tecnico.setApPaterno(lector.next());
            System.out.println("Ingrese Apellido Materno: ");
            Tecnico.setApMaterno(lector.next());
            System.out.println("Ingrese Especialidad: ");
            Tecnico.setEspecialidad(lector.next());
            System.out.println("Ingrese Total de Sueldo: ");
            Tecnico.setSueldo(lector.nextDouble());
            System.out.println("Ingrese Total de Comision: ");
            Tecnico.setComision(lector.nextDouble());
        }
        public void ImprimirDatos()
        {
            System.out.println("ID del Tecnico: " + Tecnico.getIDTecnico());
            System.out.println("Nombre(s): " + Tecnico.getNombre());
            System.out.println("Apellido Paterno: " + Tecnico.getApPaterno());
            System.out.println("Apellido Materno: " + Tecnico.getApMaterno());
            System.out.println("Especialidad: " + Tecnico.getEspecialidad());
            System.out.println("Total del Sueldo: " + Tecnico.getSueldo());
            System.out.println("Total de Comision: " + Tecnico.getComision());
        }
    }
}
