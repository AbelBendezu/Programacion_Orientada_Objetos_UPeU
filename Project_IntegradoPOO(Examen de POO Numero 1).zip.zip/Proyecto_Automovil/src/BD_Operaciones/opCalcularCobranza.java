package BD_Operaciones;

import  BD_Informacion.infoRevision;
import  java.util.Scanner;
public class opCalcularCobranza 
{
    static public double CalcularCobranza()
    {
        Scanner lector = new Scanner(System.in);
        double CalcularCobranza          = 0;
        double Tiempo_Planificado        = infoRevision.Revision.Tiempo_Planificado;
        double Tiempo_Revision_Utilizado = infoRevision.Revision.Tiempo_Revision_Utilizado;
        //Funcion Leer Datos
        System.out.println("Ingrese el Tiempo Planificado: ");
        Tiempo_Planificado = lector.nextDouble();
        System.out.println("Ingrese el Tiempo Utilizado: ");
        Tiempo_Revision_Utilizado = lector.nextDouble();
        CalcularCobranza = (Tiempo_Planificado + Tiempo_Revision_Utilizado)/2*5;
        //Funcion ImprimirDatos
        System.out.println("Calcular Cobranza: " + ("Su importe total es") + CalcularCobranza);
        return (1);
    }  
}
