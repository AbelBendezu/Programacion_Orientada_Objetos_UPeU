package BD_Operaciones;

import  BD_Operaciones.opSalario;
import java.util.Scanner;
public class opComision 
{
    public static class Comision
    {
        static private int          NumAutosAtendidos;
        static private opSalario    Numero_de_Horas;
        static private double       TopeAtencion;
        static private double       TopeDiario;
        //Metodo Set&Get
        public static int getNumAutosAtendidos() 
        {
            return NumAutosAtendidos;
        }
        public static void setNumAutosAtendidos(int NumAutosAtendidos) 
        {
            Comision.NumAutosAtendidos = NumAutosAtendidos;
        }
        public static opSalario getNumero_de_Horas() 
        {
            return Numero_de_Horas;
        }
        public static void setNumero_de_Horas(opSalario Numero_de_Horas)
        {
            Comision.Numero_de_Horas = Numero_de_Horas;
        }
        public static double getTopeAtencion()
        {
            return TopeAtencion;
        }
        public static void setTopeAtencion(double TopeAtencion) 
        {
            Comision.TopeAtencion = TopeAtencion;
        }
        public static double getTopeDiario() 
        {
            return TopeDiario;
        }
        public static void setTopeDiario(double TopeDiario) 
        {
            Comision.TopeDiario = TopeDiario;
        }
        public Comision() 
        {
            Comision.setNumAutosAtendidos(1);
            Comision.setNumero_de_Horas(Numero_de_Horas);
            Comision.setTopeAtencion(1);
            Comision.setTopeDiario(1);
        }
        public Comision(int numAutos, opSalario Numero_de_Horas, double topeAtencion, double topeDiaro)
        {
            Comision.setNumAutosAtendidos(numAutos);
            Comision.setNumero_de_Horas(Numero_de_Horas);
            Comision.setTopeAtencion(topeAtencion);
            Comision.setTopeDiario(topeDiaro);
        }
        public static double LeerDatos()
        {
            Scanner lector = new Scanner(System.in);
            System.out.println("Ingrese Numero de Autos Atendidos: ");
            Comision.setNumAutosAtendidos(lector.nextInt());
            System.out.println("Ingrese Numero de Horas Trabajadas: ");
            Comision.setNumero_de_Horas(Numero_de_Horas);
            System.out.println("Ingrese Tope de Atencion: ");
            Comision.setTopeAtencion(lector.nextDouble());
            System.out.println("Ingrese Tope Diario: ");
            Comision.setTopeDiario(lector.nextDouble());
            return (1);
        }
        public static double ImprimirDatos()
        {
            System.out.println("Numero de Autos Atendidos: " + Comision.getNumAutosAtendidos());
            System.out.println("Numero de Horas Trabajadas: " + Comision.getNumero_de_Horas());
            System.out.println("Tope de Atencion: " + Comision.getTopeAtencion());
            System.out.println("Tope Diario: " + Comision.getTopeDiario());
            return (1);
        }
    }
}
