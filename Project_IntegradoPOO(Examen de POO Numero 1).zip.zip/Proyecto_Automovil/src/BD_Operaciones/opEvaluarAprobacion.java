
package BD_Operaciones;

import java.util.Scanner;
import BD_Informacion.infoAutomovil;
public class opEvaluarAprobacion 
{
    static public double EvaluarAprobacion()
    {
               Scanner lector = new Scanner(System.in);
               double Valor_General;
               int n1 = 0;
               int n2 = 0;
               int n3 = 0;
               int n4 = 0;
               int n5 = 0;
               infoAutomovil.Automovil.PuntosRevision.llantas = n1;
               infoAutomovil.Automovil.PuntosRevision.engranaje = n2;
               infoAutomovil.Automovil.PuntosRevision.nivel_frenos = n3;
               infoAutomovil.Automovil.PuntosRevision.nivel_liquidos = n4;
               infoAutomovil.Automovil.PuntosRevision.Señalizacion_optica = n5; 
               System.out.println("Indique el nivel de Aire en las Llantas");
               n1 = lector.nextInt();
               System.out.println("Indique el estado de los engranajes");
               n2 = lector.nextInt();
               System.out.println("Indique el nivel de los frenos");
               n3 = lector.nextInt();
               System.out.println("Indique el nivel de liquidos");
               n4 = lector.nextInt();
               System.out.println("Indique el estado de la Señalizacion Optica");
               n5 = lector.nextInt();
               Valor_General = n1+n2+n3+n4+n5;
               if(Valor_General>75)
                {
                    System.out.println("Auto Aprobado " + "Su puntaje es: " + Valor_General);
                }
                else
                    {
                if(Valor_General<75)
                {
                   System.out.println("Auto Desaprobado " + "Su puntaje es: " + Valor_General);
                }
                    }
               return (1);
    }
}
