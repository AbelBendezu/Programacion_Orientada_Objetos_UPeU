
package BD_Operaciones;
 
import java.util.Scanner;
import BD_Informacion.infoAutomovil;
import BD_Informacion.infoPropietario;

public class opRevisarAutomovil 
{
    public static double TipoAutomovil()
    {
     infoAutomovil.Automovil.setPlaca("");
     infoAutomovil.Automovil.setMarca("");
     infoAutomovil.Automovil.setModelo("");
     infoPropietario.Propietario.setNombre("");
     infoAutomovil.Automovil.setTipoMotor("");
     infoAutomovil.Automovil.setNumEjes(0);
     return 0;
    }
    public static double LeerDatos()
    {
      Scanner lector = new Scanner (System.in);
        System.out.println("Ingrese el Numero de Placa: ");
        infoAutomovil.Automovil.setPlaca(lector.next());
        System.out.println("Ingrese la Marca del Vehiculo: ");
        infoAutomovil.Automovil.setMarca(lector.next());
        System.out.println("Ingrese el Modelo del Vehiculo: ");
        infoAutomovil.Automovil.setModelo(lector.next());
        System.out.println("Ingrese el Nombre del Propietario: ");
        infoPropietario.Propietario.setNombre(lector.next());
        System.out.println("Ingrese el Tipo de Motor: ");
        infoAutomovil.Automovil.setTipoMotor(lector.next());
        System.out.println("Ingrese el Numero de Ejes: ");
        infoAutomovil.Automovil.setNumEjes(lector.nextInt());
        return 0;
    }
    public static double ImprimirDatos()
    {
        System.out.println("Numero de Placa: " + infoAutomovil.Automovil.getPlaca());
        System.out.println("Marca del Vehiculo: " + infoAutomovil.Automovil.getMarca());
        System.out.println("Modelo del Vehiculo: " + infoAutomovil.Automovil.getModelo());
        System.out.println("Nombre del Propietario: " + infoPropietario.Propietario.getNombre());
        System.out.println("Tipo de Motor: " + infoAutomovil.Automovil.getTipoMotor());
        System.out.println("Numero de Ejes: " + infoAutomovil.Automovil.getNumEjes());
        return 0;
    }
}
