
package BD_Operaciones;

import java.util.Scanner;

public class opSalario 
{
    static public double CalcularSueldo()
    {
        {
          Scanner lector = new Scanner(System.in);
          double Numero_de_Horas = 0;
          double PrecioHoras = 0;
          double SueldoFinal = 0;
          System.out.println("Introduce el Sueldo del Tecnico por Hora");
          PrecioHoras = lector.nextDouble();
          System.out.println("Introduce las horas Trabajadas por el Tecnico");
          Numero_de_Horas = lector.nextDouble();
          SueldoFinal = Numero_de_Horas*PrecioHoras;
        if(SueldoFinal > 500)
          {
              System.out.println("Mejora la Proxima Vez "
                               + "Tu saldo Actual es: " + SueldoFinal);
          }
        else
           {
        if(SueldoFinal < 500)
        {
               System.out.println("Mas empeño la proxima vez "
                                + "Tu saldo Actual es: " + SueldoFinal);
        }
           }
          return(1);
        }
    }
}