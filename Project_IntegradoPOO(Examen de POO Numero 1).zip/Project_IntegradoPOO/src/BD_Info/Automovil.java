package BD_Info;

public class Automovil 
{
    //Ingresado de Datos al Algoritmo
    private String Placa;
    private String Marca;
    private String Modelo;
    private Propietario propietario; //Clase - Dato //Clase Propietario - Dato Propietario
    private String TipoMotor;
    int NumEjes;
    //Metodo Set&Get
    public String getPlaca()
    {
        return Placa;
    }
    public void setPlaca(String Placa) 
    {
        this.Placa = Placa;
    }
    public String getMarca() 
    {
        return Marca;
    }
    public void setMarca(String Marca) 
    {
        this.Marca = Marca;
    }
    public String getModelo() 
    {
        return Modelo;
    }
    public void setModelo(String Modelo)
    {
        this.Modelo = Modelo;
    }
    public Propietario getPropietario()
    {
        return propietario;
    }
    public void setPropietario(Propietario propietario)
    {
        this.propietario = propietario;
    }
    public String getTipoMotor() 
    {
        return TipoMotor;
    }
    public void setTipoMotor(String TipoMotor)
    {
        this.TipoMotor = TipoMotor;
    }
    public int getNumEjes() 
    {
        return NumEjes;
    }
    public void setNumEjes(int NumEjes) 
    {
        this.NumEjes = NumEjes;
    }
    
}
