package BD_Info;

public class Propietario 
{
    //Ingreso de Datos al Algoritmo
    private String DNI;
    private String Nombre;
    private String ApPaterno;
    private String ApMaterno;
    private String RUC;
    int Edad;
    //Metodo Set & Get
    public String getDNI() 
    {
        return DNI;
    }
    public void setDNI(String DNI)
    {
        this.DNI = DNI;
    }
    public String getNombre() 
    {
        return Nombre;
    }
    public void setNombre(String Nombre) 
    {
        this.Nombre = Nombre;
    }
    public String getApPaterno()
    {
        return ApPaterno;
    }
    public void setApPaterno(String ApPaterno) 
    {
        this.ApPaterno = ApPaterno;
    }
    public String getApMaterno() 
    {
        return ApMaterno;
    }
    public void setApMaterno(String ApMaterno) 
    {
        this.ApMaterno = ApMaterno;
    }
    public String getRUC() 
    {
        return RUC;
    }
    public void setRUC(String RUC) 
    {
        this.RUC = RUC;
    }
    public int getEdad() 
    {
        return Edad;
    }
    public void setEdad(int Edad) 
    {
        this.Edad = Edad;
    }
}
