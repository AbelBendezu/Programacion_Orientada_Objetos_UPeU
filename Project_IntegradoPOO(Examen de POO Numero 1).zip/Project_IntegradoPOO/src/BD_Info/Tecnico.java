package BD_Info;

public class Tecnico
{
    //Ingreso de datos al Algoritmo
    private int IDTecnico;
    private String Nombre;
    private String ApPaterno;
    private String ApMaterno;
    private String Especialidad;
    private double Sueldo;
    private double Comision;
    //Metodo Set & Get
    public int getIDTecnico() 
    {
        return IDTecnico;
    }
    public void setIDTecnico(int IDTecnico) 
    {
        this.IDTecnico = IDTecnico;
    }
    public String getNombre() 
    {
        return Nombre;
    }
    public void setNombre(String Nombre) 
    {
        this.Nombre = Nombre;
    }
    public String getApPaterno() 
    {
        return ApPaterno;
    }
    public void setApPaterno(String ApPaterno) 
    {
        this.ApPaterno = ApPaterno;
    }
    public String getApMaterno() 
    {
        return ApMaterno;
    }
    public void setApMaterno(String ApMaterno) 
    {
        this.ApMaterno = ApMaterno;
    }
    public String getEspecialidad() 
    {
        return Especialidad;
    }
    public void setEspecialidad(String Especialidad) 
    {
        this.Especialidad = Especialidad;
    }
    public double getSueldo() 
    {
        return Sueldo;
    }
    public void setSueldo(double Sueldo) 
    {
        this.Sueldo = Sueldo;
    }
    public double getComision() 
    {
        return Comision;
    }
    public void setComision(double Comision) 
    {
        this.Comision = Comision;
    }
    
}
