package BD_Process;

import BD_Info.Tecnico;
public class Revision extends Tecnico
{
    //Ingreso de datos al Algoritmo
    int     IDRevision;
    int     IDTecnico;
    String  FechaRevision;
    Tecnico TecnicoAsignado;
    Object  AutoRevisaado;
    double  TiemploPlanificado;
    double  TiempoRevUtilizado;
    int     TipoAutoRevisar;
    //Metodo Set&Get
    public int getIDRevision() 
    {
        return IDRevision;
    }
    public void setIDRevision(int IDRevision) 
    {
        this.IDRevision = IDRevision;
    }
    public int getIDTecnico() 
    {
        return IDTecnico;
    }
    public void setIDTecnico(int IDTecnico) 
    {
        this.IDTecnico = IDTecnico;
    }
    public String getFechaRevision() 
    {
        return FechaRevision;
    }
    public void setFechaRevision(String FechaRevision) 
    {
        this.FechaRevision = FechaRevision;
    }
    public Tecnico getTecnicoAsignado() 
    {
        return TecnicoAsignado;
    }
    public void setTecnicoAsignado(Tecnico TecnicoAsignado) 
    {
        this.TecnicoAsignado = TecnicoAsignado;
    }
    public Object getAutoRevisaado()
    {
        return AutoRevisaado;
    }
    public void setAutoRevisaado(Object AutoRevisaado)
    {
        this.AutoRevisaado = AutoRevisaado;
    }
    public double getTiemploPlanificado() 
    {
        return TiemploPlanificado;
    }
    public void setTiemploPlanificado(double TiemploPlanificado)
    {
        this.TiemploPlanificado = TiemploPlanificado;
    }
    public double getTiempoRevUtilizado() 
    {
        return TiempoRevUtilizado;
    }
    public void setTiempoRevUtilizado(double TiempoRevUtilizado)
    {
        this.TiempoRevUtilizado = TiempoRevUtilizado;
    }
    public int getTipoAutoRevisar() 
    {
        return TipoAutoRevisar;
    }
    public void setTipoAutoRevisar(int TipoAutoRevisar) 
    {
        this.TipoAutoRevisar = TipoAutoRevisar;
    }   
}
