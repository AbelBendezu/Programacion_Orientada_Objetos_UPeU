package BD_Info;

import java.util.Scanner;

public class Automovil 
{
    //Ingresado de Datos al Algoritmo
    private String Placa;
    private String Marca;
    private String Modelo;
    private Propietario propietario; //Clase - Dato //Clase Propietario - Dato Propietario
    private String TipoMotor;
    private int NumEjes;
    private double llantas;
    private double engranaje;
    private double nivel_frenos;
    private double nivel_liquidos;
    private double Señalizacion_optica;
    //Metodo Set&Get
    public String getPlaca()
    {
        return Placa;
    }
    public void setPlaca(String Placa) 
    {
        this.Placa = Placa;
    }
    public String getMarca() 
    {
        return Marca;
    }
    public void setMarca(String Marca) 
    {
        this.Marca = Marca;
    }
    public String getModelo() 
    {
        return Modelo;
    }
    public void setModelo(String Modelo)
    {
        this.Modelo = Modelo;
    }
    public Propietario getPropietario()
    {
        return propietario;
    }
    public void setPropietario(Propietario propietario)
    {
        this.propietario = propietario;
    }
    public String getTipoMotor() 
    {
        return TipoMotor;
    }
    public void setTipoMotor(String TipoMotor)
    {
        this.TipoMotor = TipoMotor;
    }
    public int getNumEjes() 
    {
        return NumEjes;
    }
    public void setNumEjes(int NumEjes) 
    {
        this.NumEjes = NumEjes;
    }
    public double getLlantas() 
    {
        return llantas;
    }
    public void setLlantas(double llantas)
    {
        this.llantas = llantas;
    }
    public double getEngranaje()
    {
        return engranaje;
    }
    public void setEngranaje(double engranaje) 
    {
        this.engranaje = engranaje;
    }
    public double getNivel_frenos() 
    {
        return nivel_frenos;
    }
    public void setNivel_frenos(double nivel_frenos) 
    {
        this.nivel_frenos = nivel_frenos;
    }
    public double getNivel_liquidos() 
    {
        return nivel_liquidos;
    }
    public void setNivel_liquidos(double nivel_liquidos) 
    {
        this.nivel_liquidos = nivel_liquidos;
    }
    public double getSeñalizacion_optica() 
    {
        return Señalizacion_optica;
    }
    public void setSeñalizacion_optica(double Señalizacion_optica)
    {
        this.Señalizacion_optica = Señalizacion_optica;
    }
    //Metodos y Constructores
    public Automovil ()
    {
        this.setPlaca         ("");
        this.setMarca         ("");
        this.setModelo        ("");
        this.setPropietario   (propietario);
        this.setTipoMotor     ("");
        this.setLlantas       (1);
        this.setEngranaje     (1);
        this.setNivel_frenos  (1);
        this.setNivel_liquidos(1);
        this.setSeñalizacion_optica(1);
        
    }
    public Automovil (String placa, String marca, String modelo, Propietario Propietario, String Motor,
                      double llantas, double engranaje, double nivel_frenos, double nivel_liquidos, double señalizacion_optica )
    {
        this.setPlaca(placa);
        this.setMarca(marca);
        this.setModelo(modelo);
        this.setPropietario(Propietario);
        this.setTipoMotor(Motor);
        this.setLlantas(llantas);
        this.setEngranaje(engranaje);
        this.setNivel_frenos(nivel_frenos);
        this.setNivel_liquidos(nivel_liquidos);
        this.setSeñalizacion_optica(señalizacion_optica);
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese Numero de Placa: ");
        this.setPlaca(lector.next());
        System.out.println("Ingrese Nombre de Marca: ");
        this.setMarca(lector.next());
        System.out.println("Ingrese Numero de Modelo: ");
        this.setModelo(lector.next());
        System.out.println("Ingrese Nombre Propietario: ");
        this.setPropietario(propietario);
        System.out.println("Ingrese Tipo de Motor: ");
        this.setTipoMotor(lector.next());
    }
    public void Imprimir()
    {
        System.out.println("Numero de Placa: " + this.getPlaca());
        System.out.println("Marca: " + this.getMarca());
        System.out.println("Modelo: " + this.getModelo());
        System.out.println("Nombre de Propietario: " + this.propietario);
        System.out.println("Tipó de Motor: " + this.getTipoMotor());
    }
}
