package BD_Info;

import java.util.Scanner;

public class Propietario 
{
    //Ingreso de Datos al Algoritmo
    private String DNI;
    private String Nombre;
    private String ApPaterno;
    private String ApMaterno;
    private String RUC;
    int Edad;
    //Metodo Set & Get
    public String getDNI() 
    {
        return DNI;
    }
    public void setDNI(String DNI)
    {
        this.DNI = DNI;
    }
    public String getNombre() 
    {
        return Nombre;
    }
    public void setNombre(String Nombre) 
    {
        this.Nombre = Nombre;
    }
    public String getApPaterno()
    {
        return ApPaterno;
    }
    public void setApPaterno(String ApPaterno) 
    {
        this.ApPaterno = ApPaterno;
    }
    public String getApMaterno() 
    {
        return ApMaterno;
    }
    public void setApMaterno(String ApMaterno) 
    {
        this.ApMaterno = ApMaterno;
    }
    public String getRUC() 
    {
        return RUC;
    }
    public void setRUC(String RUC) 
    {
        this.RUC = RUC;
    }
    public int getEdad() 
    {
        return Edad;
    }
    public void setEdad(int Edad) 
    {
        this.Edad = Edad;
    }
    //Metodos y Constructores
    public Propietario()
    {
        this.setDNI         ("");
        this.setNombre      ("");
        this.setApPaterno   ("");
        this.setApMaterno   ("");
        this.setRUC         ("");
        this.setEdad        (0);
    }
    public Propietario(String Dni, String nombre, String apPaterno, String apMaterno, String Ruc, int edad)
    {
        this.setDNI(Dni);
        this.setNombre(nombre);
        this.setApPaterno(apPaterno);
        this.setApMaterno(apMaterno);
        this.setRUC(Ruc);
        this.setEdad(edad);
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println  ("Ingrese Numero de DNI: ");
        this.setDNI(lector.next());
        System.out.println  ("Ingrese Nombre: ");
        this.setNombre(lector.next());
        System.out.println  ("Ingrese Apellido Paterno: ");
        this.setApPaterno(lector.next());
        System.out.println  ("Ingrese Apellido Materno: ");
        this.setApMaterno(lector.next());
        System.out.println  ("Ingrese Numero de RUC: ");
        this.setRUC(lector.next());
        System.out.println  ("Ingrese Edad Actual: ");
        this.setEdad(lector.nextInt());
    }
    public void Imprimir()
    {
        System.out.println    ("Numero de DNI: " + this.getDNI());
        System.out.println    ("Nombre: " + this.getNombre());
        System.out.println    ("Apellido Paterno: " + this.getApPaterno());
        System.out.println    ("Apellido Materno: " + this.getApMaterno());
        System.out.println    ("Numero de RUC: " + this.getRUC());
        System.out.println    ("Edad Actual: " + this.getEdad());
    }
}
