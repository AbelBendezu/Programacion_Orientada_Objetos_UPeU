package BD_Info;

import java.util.Scanner;

public class Tecnico
{
    //Ingreso de datos al Algoritmo
    private int IDTecnico;
    private String Nombre;
    private String ApPaterno;
    private String ApMaterno;
    private String Especialidad;
    private double Sueldo;
    private double Comision;
    //Metodo Set & Get
    public int getIDTecnico() 
    {
        return IDTecnico;
    }
    public void setIDTecnico(int IDTecnico) 
    {
        this.IDTecnico = IDTecnico;
    }
    public String getNombre() 
    {
        return Nombre;
    }
    public void setNombre(String Nombre) 
    {
        this.Nombre = Nombre;
    }
    public String getApPaterno() 
    {
        return ApPaterno;
    }
    public void setApPaterno(String ApPaterno) 
    {
        this.ApPaterno = ApPaterno;
    }
    public String getApMaterno() 
    {
        return ApMaterno;
    }
    public void setApMaterno(String ApMaterno) 
    {
        this.ApMaterno = ApMaterno;
    }
    public String getEspecialidad() 
    {
        return Especialidad;
    }
    public void setEspecialidad(String Especialidad) 
    {
        this.Especialidad = Especialidad;
    }
    public double getSueldo() 
    {
        return Sueldo;
    }
    public void setSueldo(double Sueldo) 
    {
        this.Sueldo = Sueldo;
    }
    public double getComision() 
    {
        return Comision;
    }
    public void setComision(double Comision) 
    {
        this.Comision = Comision;
    }
    //Metodos y Constructores
    public Tecnico()
    {
        this.setIDTecnico(0);
        this.setNombre("");
        this.setApPaterno("");
        this.setApMaterno("");
        this.setEspecialidad("");
        this.setSueldo(0);
        this.setComision(0);
    }
    public double CalcularSueldo()
      {
          Scanner entrada = new Scanner(System.in);
          double NroHoras = 0;
          double PrecioHoras = 0;
          double SueldoFinal = 0;
          System.out.println("Introduce el Sueldo del Tecnico por Hora");
          PrecioHoras = entrada.nextDouble();
          System.out.println("Introduce las horas Trabajadas por el Tecnico");
          NroHoras = entrada.nextDouble();
          if(NroHoras>10)
          {
              SueldoFinal=NroHoras*5;
          }
          else
          {
              if(NroHoras<10)
              {
               SueldoFinal=NroHoras*0.5;
              }
          }
          return (1);
      }
    public double CalcularComision()
      {
          Scanner entrada = new Scanner(System.in);
          double Comision = 0;
          double AutosAtendidos = 0;
          double SueldoFinal;
          System.out.println("Introduce el Numero de Autos Atendidos");
          AutosAtendidos = entrada.nextDouble();
          if(AutosAtendidos>10)
          {
              SueldoFinal=AutosAtendidos+10;
          }
          else
          {
              if(AutosAtendidos<10)
              {
               SueldoFinal=AutosAtendidos+0;
              }
          }
          return (1);
      }
    public Tecnico(int IDTecnico, String Nombre, String apPaterno, String apMaterno, String Especialidad, double Sueldo, double Comision)
    {
        this.setIDTecnico(IDTecnico);
        this.setNombre(Nombre);
        this.setApPaterno(apPaterno);
        this.setApMaterno(apMaterno);
        this.setEspecialidad(Especialidad);
        this.setSueldo(Sueldo);
        this.setComision(Comision);
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println  ("Escriba el ID del Tecnico");
        this.setIDTecnico(lector.nextInt());
        System.out.println  ("Escriba Nombre del Tecnico");
        this.setNombre(lector.next());
        System.out.println  ("Ingrese su Apellido Paterno");
        this.setApPaterno(lector.next());
        System.out.println  ("Ingrese su Apellido Materno");
        this.setApMaterno(lector.next());
        System.out.println  ("Ingrese su Especialidad");
        this.setEspecialidad(lector.next());
        System.out.println  ("Ingrese su Sueldo");
        this.setSueldo(lector.nextDouble());
        System.out.println  ("Ingrese Comision");
        this.setComision(lector.nextDouble());
    }
    public void Imprimir()
    {
        System.out.println  ("ID del Tecnico: " + this.getIDTecnico());
        System.out.println  ("Nombre del Tecnico: " + this.getNombre());
        System.out.println  ("Apellido Paterno: " + this.getApPaterno());
        System.out.println  ("Apellido Materno: " + this.getApMaterno());
        System.out.println  ("Especialidad: " + this.getEspecialidad());
        System.out.println  ("Sueldo: " + this.getSueldo());
        System.out.println  ("Comision: " + this.getComision());
    }
}
