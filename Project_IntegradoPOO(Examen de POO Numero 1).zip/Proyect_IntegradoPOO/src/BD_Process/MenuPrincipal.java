
package BD_Process;
import BD_Info.Automovil;
import BD_Info.Propietario;
import BD_Info.Tecnico;
import java.util.Scanner;
public class MenuPrincipal 
{
    public static void main(String[] args) 
    {
        Scanner lector = new Scanner(System.in);
        double Menu = 0;
        System.out.println("Bienvenido al Menu");
        Menu = lector.nextDouble();
        System.out.println("1. Calcular Sueldo Tecnico ");
        Tecnico calcularsueldo ;
    }
}
