package BD_Process;

import BD_Info.Tecnico;
import BD_Info.Automovil;
import java.util.Scanner;

public class Revision extends Tecnico
{
    //Ingreso de datos al Algoritmo
    int     IDRevision;
    int     IDTecnico;
    String  FechaRevision;
    Tecnico TecnicoAsignado;
    Object  AutoRevisaado;
    double  TiemploPlanificado;
    double  TiempoRevUtilizado;
    int     TipoAutoRevisar;
    boolean ResultadoRev;
    //Metodo Set&Get
    public int getIDRevision() 
    {
        return IDRevision;
    }
    public void setIDRevision(int IDRevision) 
    {
        this.IDRevision = IDRevision;
    }
    public int getIDTecnico() 
    {
        return IDTecnico;
    }
    public void setIDTecnico(int IDTecnico) 
    {
        this.IDTecnico = IDTecnico;
    }
    public String getFechaRevision() 
    {
        return FechaRevision;
    }
    public void setFechaRevision(String FechaRevision) 
    {
        this.FechaRevision = FechaRevision;
    }
    public Tecnico getTecnicoAsignado() 
    {
        return TecnicoAsignado;
    }
    public void setTecnicoAsignado(Tecnico TecnicoAsignado) 
    {
        this.TecnicoAsignado = TecnicoAsignado;
    }
    public Object getAutoRevisaado()
    {
        return AutoRevisaado;
    }
    public void setAutoRevisaado(Object AutoRevisaado)
    {
        this.AutoRevisaado = AutoRevisaado;
    }
    public double getTiemploPlanificado() 
    {
        return TiemploPlanificado;
    }
    public void setTiemploPlanificado(double TiemploPlanificado)
    {
        this.TiemploPlanificado = TiemploPlanificado;
    }
    public double getTiempoRevUtilizado() 
    {
        return TiempoRevUtilizado;
    }
    public void setTiempoRevUtilizado(double TiempoRevUtilizado)
    {
        this.TiempoRevUtilizado = TiempoRevUtilizado;
    }
    public int getTipoAutoRevisar() 
    {
        return TipoAutoRevisar;
    }
    public void setTipoAutoRevisar(int TipoAutoRevisar) 
    {
        this.TipoAutoRevisar = TipoAutoRevisar;
    }   
    public boolean isResultadoRev() 
    {
        return ResultadoRev;
    }
    public void setResultadoRev(boolean ResultadoRev) 
    {
        this.ResultadoRev = ResultadoRev;
    }
    //Metodos y Constructores
    public Revision()
    {
        this.setIDRevision(0);
        this.setIDTecnico(0);
        this.setFechaRevision("");
        this.setTecnicoAsignado(TecnicoAsignado);
        this.setAutoRevisaado("");
        this.setTiemploPlanificado(0);
        this.setTiempoRevUtilizado(0);
        this.setTipoAutoRevisar(0);
        this.setResultadoRev(ResultadoRev);
    } 
    public void RevisionAuto(int TipoAutomovil) 
            {
               
               Automovil llantas;
               Automovil engranaje;
               Automovil nivel_frenos;
               Automovil nivel_liquidos;
               Automovil Señalizacion_optica;
               Scanner lector = new Scanner(System.in);
               System.out.println("Indique el nivel de Aire en las Llantas");
               
               System.out.println("Indique el estado de los engranajes");
               engranaje.setEngranaje(1);
               System.out.println("Indique el nivel de los frenos");
               nivel_frenos.setNivel_frenos(TiemploPlanificado);
               System.out.println("Indique el nivel de liquidos");
               nivel_liquidos.setNivel_liquidos(1);
               System.out.println("Indique el estado de la Señalizacion Optica");
               Señalizacion_optica.setSeñalizacion_optica(1);
            }
    public Revision(int idRevision, int idTecnico, String fechaRevision, Tecnico tecnicoAsignado,
                    Object autorevisado, double tiempoPlanificado, double tiempoRevUtilizado, int tipoAutoRevisar, boolean resultadoRev)
    {
        this.setIDRevision(idRevision);
        this.setIDTecnico(idTecnico);
        this.setFechaRevision(fechaRevision);
        this.setTecnicoAsignado(tecnicoAsignado);
        this.setAutoRevisaado(autorevisado);
        this.setTiemploPlanificado(tiempoPlanificado);
        this.setTiempoRevUtilizado(tiempoRevUtilizado);
        this.setTipoAutoRevisar(tipoAutoRevisar);
        this.setResultadoRev(resultadoRev);
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese ID de Revision");
        this.setIDRevision(lector.nextInt());
        System.out.println("Ingrese ID de Tecnico");
        this.setIDTecnico(lector.nextInt());
        System.out.println("Ingrese Fecha de Revision");
        this.setFechaRevision(lector.next());
        System.out.println("Ingrese Tecnico Asignado");
        this.setTecnicoAsignado(TecnicoAsignado);
        System.out.println("Ingrese Auto Revisado");
        this.setAutoRevisaado(lector.next());
        System.out.println("Ingrese Tiempo Planificado");
        this.setTiemploPlanificado(lector.nextDouble());
        System.out.println("Ingrese Tiempo Revision Utilizado");
        this.setTiempoRevUtilizado(lector.nextDouble());
        System.out.println("Ingrese Tipo de Auto a Revisar");
        this.setTipoAutoRevisar(lector.nextInt());
        System.out.println("Ingrese Resultado de la Revision");
        this.setResultadoRev(ResultadoRev);
    }
    public void ImprimirDatos()
    {
        System.out.println("ID de Revision: " + this.getIDRevision());
        System.out.println("ID de Tecnico: " + this.getIDTecnico());
        System.out.println("Fecha de Revision: " + this.getFechaRevision());
        System.out.println("Tecnico Asignado: " + this.getTecnicoAsignado());
        System.out.println("Auto Revisado: " + this.getAutoRevisaado());
        System.out.println("Tiempo Planificado: " + this.getTiemploPlanificado());
        System.out.println("Tiempo Revision Utilizado: " + this.getTiempoRevUtilizado());
        System.out.println("Tipo de Auto Revisado:" + this.getTipoAutoRevisar());
        System.out.println("Resultado de Revision: " + this.isResultadoRev());
    }
}
