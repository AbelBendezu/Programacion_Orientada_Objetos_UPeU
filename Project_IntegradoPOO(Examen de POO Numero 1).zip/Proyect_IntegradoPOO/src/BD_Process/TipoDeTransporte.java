
package BD_Process;

import BD_Info.Automovil;

public class TipoDeTransporte
{
    public class Bus extends Automovil
    {
        
    }
    public class AutoParticular extends Automovil
    {
        
    }
    public class Moto extends Automovil
    {
        
    }
}

