
package BD_Process;

import BD_Info.Propietario;
import java.util.Scanner;

public class Tipo_de_Pago 
{
    public class Metodo_Factura extends Propietario
    {
        //Ingreso de Datos al Algoritmo
        private int         NumFactura;
        private Propietario TitularMov;
        private int         IDRevision;
        private String      FechaEmision;
        private int         RUC_Cliente;
        //Metodo Set & Get
        public int getNumFactura() 
        {
            return NumFactura;
        }
        public void setNumFactura(int NumFactura) 
        {
            this.NumFactura = NumFactura;
        }
        public Propietario getTitularMov() 
        {
            return TitularMov;
        }
        public void setTitularMov(Propietario TitularMov) 
        {
            this.TitularMov = TitularMov;
        }
        public int getIDRevision() 
        {
            return IDRevision;
        }
        public void setIDRevision(int IDRevision) 
        {
            this.IDRevision = IDRevision;
        }
        public String getFechaEmision() 
        {
            return FechaEmision;
        }
        public void setFechaEmision(String FechaEmision) 
        {
            this.FechaEmision = FechaEmision;
        }
        public int getRUC_Cliente() 
        {
            return RUC_Cliente;
        }
        public void setRUC_Cliente(int RUC_Cliente) 
        {
            this.RUC_Cliente = RUC_Cliente;
        }
        //Metodos de Constructores
        public Metodo_Factura()
        {
            this.setNumFactura(0);
            this.setTitularMov(TitularMov);
            this.setIDRevision(0);
            this.setFechaEmision("");
            this.setRUC_Cliente(0);
        }
        public Metodo_Factura(int numFactura, Propietario TitularMov, int idRevision, String fechaEmision, int rucCliente)
        {
            this.setNumFactura(numFactura);
            this.setTitularMov(TitularMov);
            this.setIDRevision(idRevision);
            this.setFechaEmision(fechaEmision);
            this.setRUC_Cliente(rucCliente);
        }
        public void LeerDatos()
        {
            Scanner lector = new Scanner(System.in);
            System.out.println("Ingrese Numero de Factura");
            this.setNumFactura(lector.nextInt());
            System.out.println("Ingrese Titular de Movilidad");
            this.setTitularMov(TitularMov);
            System.out.println("Ingrese ID de Revision");
            this.setIDRevision(lector.nextInt());
            System.out.println("Ingrese Fecha de Emision");
            this.setFechaEmision(lector.next());
            System.out.println("Ingrese RUC del Cliente");
            this.setRUC_Cliente(lector.nextInt());
        }
        public void ImprimirDatos()
        {
            System.out.println("Numero de Factura: " + this.getNumFactura());
            System.out.println("Titular de Movilidad: " + this.getTitularMov());
            System.out.println("ID de Revision: " + this.getIDRevision());
            System.out.println("Fecha de Emision: " + this.getFechaEmision());
            System.out.println("RUC del Cliente: " + this.getRUC_Cliente());
        }
    }      
}