package BD_Informacion;

import java.util.Scanner;

public class Agencia 
{
    public static class agencia
    {
        static private String nomAgencia;
        static private String direccion;
        //Get&Set
        public static String getNomAgencia() 
        {
            return nomAgencia;
        }
        public static void setNomAgencia(String nomAgencia) 
        {
            agencia.nomAgencia = nomAgencia;
        }
        public static String getDireccion() 
        {
            return direccion;
        }
        public static void setDireccion(String direccion) 
        {
            agencia.direccion = direccion;
        }
        //Constructor
        public agencia() 
        {
            agencia.setNomAgencia("");
            agencia.setDireccion("");
        }
        public agencia(String NomAgencia, String direccion)
        {
            agencia.setNomAgencia(NomAgencia);
            agencia.setDireccion(direccion);
        }
        public void LeerDatos()
        {
            Scanner lector = new Scanner(System.in);
            System.out.println("Ingrese Nombre de la Agencia: ");
            agencia.setNomAgencia(lector.next());
            System.out.println("Ingrese Direccion de la Agencia: ");
            agencia.setDireccion(lector.next());
        }
        public void ImprimirDatos()
        {
            System.out.println("Nombre de la Agencia: " + agencia.getNomAgencia());
            System.out.println("Direccion de la Agencia: " + agencia.getDireccion());
        }
    }
}
