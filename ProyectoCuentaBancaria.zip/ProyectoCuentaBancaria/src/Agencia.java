
import java.util.Scanner;


public class Agencia 
{
    //Atributos:
    private String nomAgencia;
    private String direccion;
    public String getNomAgencia() 
    {
        return nomAgencia;
    }
    public void setNomAgencia(String nomAgencia) 
    {
        this.nomAgencia = nomAgencia;
    }
    public String getDireccion() 
    {
        return direccion;
    }
    public void setDireccion(String direccion) 
    {
        this.direccion = direccion;
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner (System.in);
        System.out.println("Nombre de la Agencia");
        this.setNomAgencia(lector.next());
        System.out.println("Direccion de la Agencia");
        this.setDireccion(lector.next());
    }
    public void EscribirDatos()
    {
        System.out.println("Nombre de Agencia" + this.getNomAgencia());
        System.out.println("Direccion" + this.getDireccion());
    }
}
