
import java.util.Scanner;


public class Cliente
{
    private String direccion;

    public String getDireccion() 
    {
        return direccion;
    }
    public Cliente()
    {
        this.setDireccion("");
    }
    public Cliente(String pDireccion)
    {
        this.setDireccion(pDireccion);
    }
    public void setDireccion(String direccion)
    {
        this.direccion = direccion;
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese direccion: ");
        this.setDireccion(lector.next());
    }
    public void EscribirDatos()
    {
        System.out.println("Direccion: " + this.getDireccion());
    }
}
