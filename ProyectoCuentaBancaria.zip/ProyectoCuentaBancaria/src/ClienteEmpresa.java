
import java.util.Scanner;

public class ClienteEmpresa extends Cliente
{
  private String RUC;
  private String razSocial;
  public String getRUC() 
    {
        return RUC;
    }
  public void setRUC(String RUC) 
    {
        this.RUC = RUC;
    }
  public String getRazSocial() 
    {
        return razSocial;
    }
  public void setRazSocial(String razSocial) 
    {
        this.razSocial = razSocial;
    }
  public ClienteEmpresa()
    {
      super ();
      this.setRUC("");
      this.setRazSocial("");
    }
  public ClienteEmpresa(String pRUC, String pRazonSocial, String Direccion)
    {
        super(direccion);
        this.setRUC(pRUC);
        this.setRazSocial(pRazonSocial);
    }
     //Metodos
     @Override
     public void LeerDatos()
     {
         Scanner lector = new Scanner(System.in);
         System.out.println("Escriba Razon Social: ");
         this.setRazSocial(lector.next());
         System.out.println("Escriba RUC: ");
         this.setRUC(lector.next());
         super.LeerDatos();
     }
     @Override
     public void EscribirDatos()
     {
         System.out.println("RUC: " + this.getRUC());
         super.EscribirDatos();
     }
}
