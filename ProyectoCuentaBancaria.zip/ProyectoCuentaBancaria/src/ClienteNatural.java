
import java.util.Scanner;


public class ClienteNatural extends Cliente
{
    private String Nombre;
    private String apPaterno;
    private String apMaterno;
    public String getNombre() 
    {
        return Nombre;
    }
    public void setNombre(String Nombre) 
    {
        this.Nombre = Nombre;
    }
    public String getApPaterno() 
    {
        return apPaterno;
    }
    public void setApPaterno(String apPaterno) 
    {
        this.apPaterno = apPaterno;
    }
    public String getApMaterno() 
    {
        return apMaterno;
    }
    public void setApMaterno(String apMaterno) 
    {
        this.apMaterno = apMaterno;
    }
    //Metodos
    public ClienteNatural()
    {
        super ();
        this.setNombre("");
        this.setApPaterno("");
        this.setApMaterno("");
    }
    public ClienteNatural(String pNombre, String pApPaterno, String pApMaterno, String direccion)
    {
     super (direccion);
     this.setNombre(pNombre);
     this.setApPaterno(pApPaterno);
     this.setApMaterno(pApMaterno);
    }
    @Override
    public void LeerDatos()
    {
        Scanner lector = new Scanner (System.in);
        System.out.println("Escriba Nombre del Cliente: ");
        this.setNombre(lector.next());
        System.out.println("Escriba Apellido Paterno: ");
        this.setApPaterno(lector.next());
        System.out.println("Escriba Apellido Materno: ");
        this.setApMaterno(lector.next());
        super.LeerDatos();
    }
    @Override
    public void EscribirDatos()
    {
        System.out.println("Nombre: " + this.getNombre());
        System.out.println("Apellido Paterno: " + this.getApPaterno());
        System.out.println("Apellido Materno: " + this.getApMaterno());
        super.EscribirDatos();
    }
     }

