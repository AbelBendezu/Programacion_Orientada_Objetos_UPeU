
import java.util.Scanner;


public class Agencia 
{
    //atributos
    private String nomAgencia;
    private String direccion;
    private String tipoagencia;
    public String getNomAgencia() 
    {
        return nomAgencia;
    }
    public void setNomAgencia(String nomAgencia)
    {
        this.nomAgencia = nomAgencia;
    }
    public String getDireccion() 
    {
        return direccion;
    }
    public void setDireccion(String direccion) 
    {
        this.direccion = direccion;
    }

    public String getTipoagencia() 
    {
        return tipoagencia;
    }
    public void setTipoagencia(String tipoagencia)
    {
        this.tipoagencia = tipoagencia;
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese nombre de la Agencia");
        this.setNomAgencia(lector.next());
        System.out.println("Ingrese direccion de la Agencia");
        this.setDireccion(lector.next());
        System.out.println("Ingrese tipo de Agencia");
        this.setTipoagencia(lector.next());
    }
    public void Imprimir()
    {
        System.out.println("Nombre de Agencia: " + this.getNomAgencia());
        System.out.println("Direccion: " + this.getDireccion());
        System.out.println("Tipo de Agencia: " + this.getTipoagencia());
    }
}
