
import java.util.Scanner;


public class Agencia {
    //atributos
    private String nomAgencia;
    private String direccion;

    public String getNomAgencia() {
        return nomAgencia;
    }

    public void setNomAgencia(String nomAgencia) {
        this.nomAgencia = nomAgencia;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese nombre de la Agencia");
        this.setNomAgencia(lector.next());
        System.out.println("Ingrese direccion de la Agencia");
        this.setDireccion(lector.next());
    }
    public void Imprimir()
    {
        System.out.println("nomAgencia: " + this.getNomAgencia());
        System.out.println("direccion: " + this.getDireccion());
    }
}
