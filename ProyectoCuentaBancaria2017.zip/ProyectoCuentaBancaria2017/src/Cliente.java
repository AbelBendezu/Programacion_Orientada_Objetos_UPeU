
import java.util.Scanner;


public class Cliente {
   
    private String direccion;

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public void cliente()
    {
        this.setDireccion("");
    }       
    public void cliente(String pDireccion)
    {
        this.setDireccion(pDireccion);
    }
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese direccion");
        this.setDireccion(lector.next());
    }
    public void Imprimir()
    {
        System.out.println("Direccion: " + this.getDireccion());
    }
}
