
import java.util.Scanner;


public class ClienteEmpresa extends Cliente {
    
    private String ruc;
    private String razSocial;

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getRazSocial() {
        return razSocial;
    }

    public void setRazSocial(String razSocial) {
        this.razSocial = razSocial;
    }
    public ClienteEmpresa()
    {
        super();
        this.setRuc("");
        this.setDireccion("");
    }
    public ClienteEmpresa(String pRuc, String pRazonSocial, String direccion)
    {
        super.getDireccion();
        this.setRuc(pRuc);
        this.setRazSocial(pRazonSocial);
    }
    //Metodos:
    @Override
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Escriba RUC");
        this.setRuc(lector.next());
        System.out.println("Ingrese razon social");
        this.setRazSocial(lector.next());
    }
     @Override
    public void Imprimir()
    {
        System.out.println("RUC: " + this.getRuc());
        super.Imprimir();
    } 
    
}
