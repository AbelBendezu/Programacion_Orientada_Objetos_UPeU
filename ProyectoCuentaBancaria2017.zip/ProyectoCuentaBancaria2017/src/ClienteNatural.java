
import java.util.Scanner;


public class ClienteNatural extends Cliente {
    
    private String nombre;
    private String apPaterno;
    private String apMaterno;

    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        this.apMaterno = apMaterno;
    }
    //Metodos:
    public ClienteNatural()
    {
        super();
        this.setNombre("");
        this.setApPaterno("");
        this.setApMaterno("");
    }
    public ClienteNatural(String pNombre, String pApPaterno, String pApMaterno, String direccion)
    {
        super.getDireccion();
        this.setNombre(pNombre);
        this.setApPaterno(pApPaterno);
        this.setApMaterno(pApMaterno);
    }
    @Override
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Escriba nombre del cliente");
        this.setNombre(lector.next());
        System.out.println("Escriba su apPaterno");
        this.setApPaterno(lector.next());
        System.out.println("Escriba su apMaterno");
        this.setApMaterno(lector.next());
    }
    @Override
    public void Imprimir()
    {
        System.out.println("nombre: " + this.getNombre());
        System.out.println("apPaterno: " + this.getApPaterno());
        System.out.println("apMaterno: " + this.getApMaterno());
        super.Imprimir();
    }
}
