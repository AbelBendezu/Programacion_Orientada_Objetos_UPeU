
import java.util.Scanner;


public class ClienteNatural extends Cliente {
    
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private char Genero;

    public String getNombre() 
    {
        return nombre;
    }
    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }   
    public String getApPaterno()
    {
        return apPaterno;
    }
    public void setApPaterno(String apPaterno)
    {
        this.apPaterno = apPaterno;
    }
    public String getApMaterno() 
    {
        return apMaterno;
    }
    public void setApMaterno(String apMaterno)
    {
        this.apMaterno = apMaterno;
    }
    public char getGenero() 
    {
        return Genero;
    }

    public void setGenero(char Genero) 
    {
        this.Genero = Genero;
    }
    //Metodos:
    public ClienteNatural()
    {
        super();
        this.setNombre("");
        this.setApPaterno("");
        this.setApMaterno("");
        this.setGenero('M');
        this.setGenero('F');
    }
    public ClienteNatural(String pNombre, String pApPaterno, String pApMaterno, String direccion, char Genero)
    {
        super.getDireccion();
        this.setNombre(pNombre);
        this.setApPaterno(pApPaterno);
        this.setApMaterno(pApMaterno);
        this.setGenero(Genero);
    }
    @Override
    public void LeerDatos()
    {
        Scanner lector = new Scanner(System.in);
        System.out.println("Escriba nombre del cliente");
        this.setNombre(lector.next());
        System.out.println("Escriba su apPaterno");
        this.setApPaterno(lector.next());
        System.out.println("Escriba su apMaterno");
        this.setApMaterno(lector.next());
        System.out.println("Especifique su Genero");
        this.setGenero(lector.next().charAt(0));
    }
    @Override
    public void Imprimir()
    {
        System.out.println("nombre: "       + this.getNombre());
        System.out.println("apPaterno: "    + this.getApPaterno());
        System.out.println("apMaterno: "    + this.getApMaterno());
        System.out.println("Genero: "       + this.getGenero());
        super.Imprimir();
    }
}
