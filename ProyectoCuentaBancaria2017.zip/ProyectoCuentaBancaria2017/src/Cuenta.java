e
import java.util.Scanner;


public class Cuenta {
    
    private int nroCuenta;
    private Object propietario;
    private int tipoCliente;
    private Agencia agencia;
    private double saldo;

    public int getNroCuenta() {
        return nroCuenta;
    }

    public void setNroCuenta(int nroCuenta) {
        this.nroCuenta = nroCuenta;
    }

    public Object getPropietario() {
        return propietario;
    }

    public void setPropietario(Object propietario) {
        this.propietario = propietario;
    }

    public int getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(int tipoCliente) {
        this.tipoCliente = tipoCliente;
    }

    public Agencia getAgencia() {
        return agencia;
    }

    public void setAgencia(Agencia agencia) {
        this.agencia = agencia;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    public void CerrarCuenta()
    {
        
    }
    public boolean Depositar(double monto)
    {
        if (monto>10)
        {
            this.setSaldo(this.getSaldo()+monto);
            return true;
        }
        else
        {
            return false;
        }
    }
    public boolean Abonar(double monto)
    {
        if (monto>20)
        {
            this.setSaldo(this.getSaldo()+monto);
            return true;
        }
        return false;
    }
    public boolean Retirar(double monto)
    {
        if (monto>this.getSaldo())
        {
            return false;
        }
        this.setSaldo(this.getSaldo()-monto);
        return false;
    }
    public double VerSaldo()
    {
        return this.getSaldo();
    }
    public void AbrirCuenta(int tipo)
    {
        Scanner lector = new Scanner(System.in);
        //System.out.println("Asigne un numero de cuenta:");
        this.setNroCuenta(tipo);
        System.out.println("Ingrese el numero de cuenta:");
        this.setNroCuenta(lector.nextInt());
        if (tipo==1)
        {//cliente natural
            ClienteNatural oCN = new ClienteNatural();
            oCN.LeerDatos();
            this.setPropietario(oCN);
            this.setTipoCliente(tipo);
            this.setSaldo(0);
        }
        else
        {
           ClienteEmpresa oCE = new ClienteEmpresa();
            oCE.LeerDatos();
            this.setPropietario(oCE);
            this.setTipoCliente(tipo);
            this.setSaldo(0); 
        }
        Agencia oAgencia = new Agencia();
        oAgencia.LeerDatos();
        this.setAgencia(oAgencia);
    }
    public void Imprimir()
    {
        System.out.println("Nro. de cuenta: " + this.getNroCuenta());
        if (this.getTipoCliente()==1)
        {//Cliente natural:
            ClienteNatural oCN= (ClienteNatural) this.getPropietario();
            oCN.Imprimir();
        }
        else
        {//Cliente empresarial
            ClienteEmpresa oCE = (ClienteEmpresa) this.getPropietario();
            oCE.Imprimir();
        }
        System.out.println("Agencia: " + this.getAgencia().getNomAgencia());
        System.out.println("Saldo S/. " + this.getSaldo());
        this.getAgencia().Imprimir();
    }
}
