
import java.util.Scanner;

public class Programa 
{
    public static void main(String[] args) 
    {
        Scanner lector = new Scanner(System.in);
        int tipoC;
        System.out.println("Tipo de cliente a Crear");
        tipoC = lector.nextInt();
        Cuenta oCuenta = new Cuenta();
        oCuenta.AbrirCuenta(tipoC);
        oCuenta.Imprimir();
        System.out.println("Monto a Abonar");
        double montoAbono = lector.nextDouble();
        if (oCuenta.Abonar(montoAbono)==true)
        {
            System.out.println("Se abono correctamente.");
            oCuenta.VerSaldo();
        }
        else
        {
            System.out.println("Monto Insuficiente.");
            System.out.println("Saldo es: " + oCuenta.VerSaldo());
        }
        System.out.println("Monto a Retirar");
        double montoRetiro = lector.nextDouble();
        if (oCuenta.Retirar(montoRetiro)==true)
        {
            System.out.println("Retiro exitoso.");
            System.out.println("Saldo es: " + oCuenta.VerSaldo());
        }
        else
        {
            System.out.println("Saldo Insuficiente");
        }
    }
}
