package BD_Info;

public class Agencia 
{
    public static class agencia
    {
      //Atributos:
        private String nomAgencia;
        private String direccion;
        private int categoria;
        private int aforo;
        private String gerente;
      //Metodos Set&Get
        public String getNomAgencia() 
        {
            return nomAgencia;
        }
        public void setNomAgencia(String nomAgencia) 
        {
            this.nomAgencia = nomAgencia;
        }
        public String getDireccion() 
        {
            return direccion;
        }
        public void setDireccion(String direccion) 
        {
            this.direccion = direccion;
        }
        public int getCategoria() 
        {
            return categoria;
        }
        public void setCategoria(int categoria) 
        {
            this.categoria = categoria;
        }
        public int getAforo() 
        {
            return aforo;
        }
        public void setAforo(int aforo)
        {
            this.aforo = aforo;
        }
        public String getGerente() 
        {
            return gerente;
        }
        public void setGerente(String gerente) 
        {
            this.gerente = gerente;
        }
        
    }
}
