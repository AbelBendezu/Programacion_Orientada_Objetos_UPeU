package BD_Info;
import java.util.ArrayList;

public class ListaAgencias 
{
    public static class listaagencias
    {
        private static ArrayList<Agencia> listaAg= new ArrayList<Agencia>();
        public static void AgregarAgencia(Agencia x)
        {
        listaAg.add(x);
        }
        public static ArrayList<Agencia> Listar()
        {
        return listaAg;
        }
        public static int NumeroAgenciasEnLista()
        { 
        return listaAg.size();
        }
    }
}
